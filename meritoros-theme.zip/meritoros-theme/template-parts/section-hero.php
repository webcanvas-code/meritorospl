<?php
$bg_img    = get_field('hero_bg_image');
$bg_url    = is_array($bg_img) ? esc_url($bg_img['url']) : 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&w=2070&q=80';
$bg_alt    = is_array($bg_img) ? esc_attr($bg_img['alt']) : 'Team meeting';
$headline  = mer_field('hero_headline', "Eksperci w księgowości.\nTechnologia i pewność\nw działaniu.");
$sub       = mer_field('hero_subheadline', 'Zapewniamy księgowość kadry i outsourcing procesów w standardzie, który daje firmom spokój i bezpieczeństwo.');
$btn1_text = mer_field('hero_btn1_text', 'Poznaj ofertę');
$btn1_url  = mer_field('hero_btn1_url', '#uslugi');
$btn2_text = mer_field('hero_btn2_text', 'Porozmawiajmy');
$btn2_url  = mer_field('hero_btn2_url', '#kontakt');
$trust_text= mer_field('hero_trust_text', 'Zaufało nam ponad <span class="text-white">1200 klientów</span>');
$clients   = mer_field('hero_clients', []);

if (empty($clients)) {
    $clients = [
        ['name' => 'Streamsoft'],
        ['name' => 'SITECH'],
        ['name' => 'arco'],
        ['name' => 'ROFA'],
    ];
}
?>

<section class="relative h-screen min-h-[600px] flex flex-col justify-center overflow-hidden px-6 lg:px-12">
    <!-- Background -->
    <div class="absolute inset-0 z-0">
        <img src="<?php echo $bg_url; ?>" alt="<?php echo $bg_alt; ?>"
             class="w-full h-full object-cover" loading="eager">
        <div class="absolute inset-0 bg-slate-900/50 mix-blend-multiply"></div>
        <div class="absolute inset-0 bg-gradient-to-r from-slate-900/95 via-slate-900/80 to-transparent"></div>
    </div>

    <!-- Content -->
    <div class="relative z-10 max-w-[1400px] mx-auto w-full flex flex-col justify-center h-full pt-28 pb-8">
        <div class="max-w-3xl w-full flex flex-col justify-center flex-1">

            <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.12] mb-6 drop-shadow-md">
                <?php echo nl2br(esc_html($headline)); ?>
            </h1>

            <p class="text-base md:text-lg lg:text-xl font-light text-slate-200 mb-8 max-w-[700px] leading-relaxed">
                <?php echo esc_html($sub); ?>
            </p>

            <div class="flex flex-wrap items-center gap-4">
                <a href="<?php echo esc_url($btn1_url); ?>"
                   class="bg-[#48c279] text-white px-7 py-3 rounded-full text-sm font-semibold hover:bg-[#3ea868] hover:shadow-lg hover:shadow-[#48c279]/30 transition-all duration-300 flex items-center gap-2 group">
                    <?php echo esc_html($btn1_text); ?>
                    <i data-lucide="arrow-right" class="w-4 h-4 group-hover:translate-x-1 transition-transform"></i>
                </a>
                <a href="<?php echo esc_url($btn2_url); ?>"
                   class="bg-white/10 backdrop-blur-md border border-white/20 text-white px-7 py-3 rounded-full text-sm font-semibold hover:bg-white/20 hover:border-white/30 transition-all duration-300 flex items-center gap-2">
                    <?php echo esc_html($btn2_text); ?>
                    <i data-lucide="message-square" class="w-4 h-4 opacity-70"></i>
                </a>
            </div>
        </div>

        <!-- Trust banner -->
        <div class="mt-auto pt-6 border-t border-white/15">
            <p class="text-xs uppercase tracking-widest text-slate-400 mb-4 font-semibold">
                <?php echo wp_kses($trust_text, ['span' => ['class' => []]]); ?>
            </p>
            <div class="flex flex-wrap items-center gap-8 lg:gap-14 opacity-60 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                <?php foreach ($clients as $client) : ?>
                    <span class="text-xl lg:text-2xl font-bold tracking-tight text-white drop-shadow-sm">
                        <?php echo esc_html($client['name'] ?? ''); ?>
                    </span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>
