<?php
$nl_label      = mer_field('nl_label', 'Newsletter');
$nl_title      = mer_field('nl_title', 'Bądź na bieżąco ze zmianami podatkowymi');
$nl_desc       = mer_field('nl_desc', 'Interesują Cię zmiany podatkowe? Szukasz pracy w obszarze księgowości lub kadr? Zapisz się i otrzymuj to, co ważne.');
$sub_count     = mer_field('nl_subscriber_count', '2 400+ czytelników');
$sub_label     = mer_field('nl_subscriber_label', 'dołączyło do naszego newslettera');
$form_title    = mer_field('nl_form_title', 'Zapisz się bezpłatnie');
$form_sub      = mer_field('nl_form_sub', 'Dołącz do ponad 2 400 specjalistów finansowych.');
$rodo          = mer_field('nl_rodo', 'Administratorem danych jest Meritoros SA, Aleja Pokoju 62/8, Kraków. Dane przetwarzane są wyłącznie w celu wysyłki newslettera.');
$privacy_url   = mer_field('nl_privacy_url', '/polityka-prywatnosci');
$terms_url     = mer_field('nl_terms_url', '/regulamin-newslettera');
$form_action   = mer_field('nl_form_action', '#');

$benefit_defaults = [
    1 => 'Miesięczne podsumowania zmian podatkowych',
    2 => 'Aktualne oferty pracy z obszaru finansów i kadr',
    3 => 'Praktyczne wskazówki i komentarze ekspertów',
    4 => 'Możliwość wypisania się w dowolnym momencie',
];
$benefits = [];
for ($i = 1; $i <= 4; $i++) {
    $text = mer_field("nl_benefit_{$i}", $benefit_defaults[$i]);
    if (!empty($text)) {
        $benefits[] = ['text' => $text];
    }
}

$topic_defaults = [
    1 => 'Zmiany podatkowe i księgowe',
    2 => 'Oferty pracy (kadry, płace, finanse)',
];
$topics = [];
for ($i = 1; $i <= 2; $i++) {
    $label = mer_field("nl_topic_{$i}", $topic_defaults[$i]);
    if (!empty($label)) {
        $topics[] = ['label' => $label];
    }
}
?>

<section class="py-20 lg:py-28 px-6 lg:px-12 bg-white border-t border-slate-100">
    <div class="max-w-[1400px] mx-auto">
        <div class="bg-slate-900 rounded-[3rem] overflow-hidden grid grid-cols-1 lg:grid-cols-2">

            <!-- Left: Branding + Benefits -->
            <div class="relative p-10 lg:p-16 flex flex-col justify-between overflow-hidden">
                <div class="absolute -bottom-16 -left-16 w-72 h-72 rounded-full bg-[#48c279]/10 blur-3xl pointer-events-none"></div>
                <div class="absolute top-8 right-8 w-40 h-40 rounded-full bg-[#48c279]/5 blur-2xl pointer-events-none"></div>

                <div class="relative z-10">
                    <div class="flex items-center mb-12">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/logo.svg'); ?>" alt="<?php bloginfo('name'); ?>" class="h-8 w-auto brightness-0 invert">
                    </div>

                    <span class="text-[#48c279] uppercase tracking-widest text-sm font-bold mb-4 block">
                        <?php echo esc_html($nl_label); ?>
                    </span>
                    <h2 class="text-3xl lg:text-4xl font-bold tracking-tight text-white leading-snug mb-6">
                        <?php echo esc_html($nl_title); ?>
                    </h2>
                    <p class="text-slate-400 text-base font-light leading-relaxed mb-10 max-w-sm">
                        <?php echo esc_html($nl_desc); ?>
                    </p>

                    <div class="flex flex-col gap-3">
                        <?php foreach ($benefits as $benefit) : ?>
                            <div class="flex items-center gap-3">
                                <div class="w-7 h-7 rounded-full bg-[#48c279]/20 flex items-center justify-center shrink-0">
                                    <i data-lucide="check" class="w-4 h-4 text-[#48c279] stroke-[2.5]"></i>
                                </div>
                                <span class="text-slate-300 text-sm font-medium">
                                    <?php echo esc_html($benefit['text'] ?? ''); ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="relative z-10 mt-12 flex items-center gap-4">
                    <!-- Fake avatars -->
                    <div class="flex -space-x-2">
                        <?php
                        $avatar_colors = ['bg-[#48c279]', 'bg-blue-500', 'bg-purple-500', 'bg-slate-600'];
                        $avatar_initials = ['AK', 'MC', 'SW', '+'];
                        foreach ($avatar_colors as $i => $color) : ?>
                            <div class="w-9 h-9 rounded-full <?php echo $color; ?> border-2 border-slate-900 flex items-center justify-center text-white text-xs font-bold">
                                <?php echo esc_html($avatar_initials[$i]); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div>
                        <p class="text-white font-bold text-sm"><?php echo esc_html($sub_count); ?></p>
                        <p class="text-slate-500 text-xs"><?php echo esc_html($sub_label); ?></p>
                    </div>
                </div>
            </div>

            <!-- Right: Form -->
            <div class="bg-white p-10 lg:p-16 flex flex-col justify-center">
                <h3 class="text-2xl font-bold tracking-tight text-slate-900 mb-2">
                    <?php echo esc_html($form_title); ?>
                </h3>
                <p class="text-slate-500 text-sm font-light mb-8">
                    <?php echo esc_html($form_sub); ?>
                </p>

                <form class="flex flex-col gap-5" method="post" action="<?php echo esc_url($form_action); ?>">
                    <?php wp_nonce_field('meritoros_newsletter', 'nl_nonce'); ?>

                    <div class="relative">
                        <div class="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400">
                            <i data-lucide="mail" class="w-5 h-5 stroke-[1.5]"></i>
                        </div>
                        <input type="email" name="email" placeholder="<?php esc_attr_e('Twój adres e-mail', 'meritoros'); ?>" required
                               class="w-full pr-5 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-slate-900 text-base placeholder:text-slate-400 focus:outline-none focus:border-[#48c279] focus:bg-white transition-all duration-200"
                               style="padding-left:3rem">
                    </div>

                    <?php if (!empty($topics)) : ?>
                        <div class="space-y-3 py-2">
                            <p class="text-xs uppercase tracking-widest text-slate-400 font-bold mb-3">
                                <?php esc_html_e('Co Cię interesuje?', 'meritoros'); ?>
                            </p>
                            <?php foreach ($topics as $i => $topic) : ?>
                                <label class="flex items-center gap-3 cursor-pointer group">
                                    <div class="relative shrink-0">
                                        <input type="checkbox" name="topics[]" value="<?php echo esc_attr($topic['label'] ?? ''); ?>"
                                               class="peer appearance-none w-5 h-5 border-2 border-slate-200 rounded-md checked:bg-[#48c279] checked:border-[#48c279] transition-colors cursor-pointer">
                                        <i data-lucide="check"
                                           class="absolute top-0.5 left-0.5 text-white w-4 h-4 opacity-0 peer-checked:opacity-100 pointer-events-none stroke-[2.5]"></i>
                                    </div>
                                    <span class="text-sm text-slate-600 group-hover:text-slate-900 transition-colors font-medium">
                                        <?php echo esc_html($topic['label'] ?? ''); ?>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <button type="submit"
                            class="w-full bg-[#48c279] text-white py-4 rounded-2xl text-base font-bold hover:bg-[#3ea868] hover:shadow-lg hover:shadow-[#48c279]/30 transition-all duration-300 flex items-center justify-center gap-2 group">
                        <?php esc_html_e('Zapisuję się', 'meritoros'); ?>
                        <i data-lucide="arrow-right" class="w-5 h-5 group-hover:translate-x-1 transition-transform"></i>
                    </button>

                    <p class="text-xs text-slate-400 leading-relaxed font-light">
                        <?php echo esc_html($rodo); ?>
                        <a href="<?php echo esc_url($privacy_url); ?>" class="underline hover:text-slate-600 transition-colors ml-1">
                            <?php esc_html_e('Polityka Prywatności', 'meritoros'); ?>
                        </a> ·
                        <a href="<?php echo esc_url($terms_url); ?>" class="underline hover:text-slate-600 transition-colors">
                            <?php esc_html_e('Regulamin Newslettera', 'meritoros'); ?>
                        </a>
                    </p>
                </form>
            </div>

        </div>
    </div>
</section>
