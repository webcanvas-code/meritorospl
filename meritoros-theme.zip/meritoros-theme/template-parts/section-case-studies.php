<?php
$label = mer_field('cs_label', 'Case Studies');
$title = mer_field('cs_title', 'Historie naszych klientów');

$cs_defaults = [
    1 => ['client_name' => 'HPC',      'logo_html' => '<span class="text-2xl lg:text-3xl font-bold tracking-tight text-[#0f4c81]">HPC</span>',       'industries' => 'Geologia inżynierska, Ochrona środowiska', 'scope_title' => 'Usługi rachunkowe, obszar kadr i płac, wsparcie w audytach',       'scope_desc' => 'Po kilku zmianach głównej księgowej spółka potrzebowała szybkiego uporządkowania księgowości i bezpiecznego zamknięcia roku obrotowego.', 'img_url' => 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=1470&q=80', 'video_label' => 'Nasz wpływ na operacje HPC',           'video_dur' => '03:45'],
    2 => ['client_name' => 'Printbox', 'logo_html' => '<span class="text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">Printbox</span>', 'industries' => 'Technologia druku, E-commerce B2B',       'scope_title' => 'Pełna obsługa BPO, rozliczenia międzynarodowe VAT OSS',           'scope_desc' => 'Przy dynamicznym wzroście sprzedaży cross-border firma potrzebowała partnera gotowego na złożone rozliczenia VAT OSS w wielu krajach UE.',   'img_url' => 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1470&q=80', 'video_label' => 'Jak Printbox skaluje finanse globalnie', 'video_dur' => '04:10'],
    3 => ['client_name' => 'SITECH',   'logo_html' => '<span class="text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">SITECH</span>',   'industries' => 'Budownictwo, Inżynieria',                  'scope_title' => 'Kadry, płace, Intrastat, rozliczenia delegacji zagranicznych',     'scope_desc' => 'Firma realizowała kontrakty w kilku krajach jednocześnie. Meritoros przejął obsługę kadrową i rozliczenia Intrastat.',                     'img_url' => 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?auto=format&fit=crop&w=1470&q=80', 'video_label' => 'Obsługa kadrowa na skalę międzynarodową','video_dur' => '05:22'],
    4 => ['client_name' => '',         'logo_html' => '', 'industries' => '', 'scope_title' => '', 'scope_desc' => '', 'img_url' => '', 'video_label' => '', 'video_dur' => ''],
];

$items = [];
for ($i = 1; $i <= 4; $i++) {
    $def         = $cs_defaults[$i];
    $client_name = mer_field("cs_{$i}_client_name", $def['client_name']);
    if (empty($client_name)) continue;
    $img_raw     = mer_field("cs_{$i}_image", $def['img_url']);
    $items[] = [
        'client_name'      => $client_name,
        'client_logo_html' => mer_field("cs_{$i}_logo_html", $def['logo_html']),
        'industries_text'  => mer_field("cs_{$i}_industries", $def['industries']),
        'scope_title'      => mer_field("cs_{$i}_scope_title", $def['scope_title']),
        'scope_desc'       => mer_field("cs_{$i}_scope_desc", $def['scope_desc']),
        'image'            => $img_raw,
        'video_label'      => mer_field("cs_{$i}_video_label", $def['video_label']),
        'video_duration'   => mer_field("cs_{$i}_video_dur", $def['video_dur']),
        'video_url'        => mer_field("cs_{$i}_video_url", '#'),
        'cta_url'          => mer_field("cs_{$i}_cta_url", '#'),
    ];
}
$total = count($items);
?>

<section class="h-screen min-h-[600px] overflow-hidden px-6 lg:px-12 bg-white flex flex-col justify-center py-10 lg:py-12">
    <div class="max-w-[1400px] mx-auto w-full flex flex-col h-full justify-center">

        <!-- Header and Navigation -->
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
                <span class="text-[#48c279] uppercase tracking-widest text-sm font-bold mb-4 block">
                    <?php echo esc_html($label); ?>
                </span>
                <h2 class="text-2xl lg:text-4xl font-bold tracking-tight text-slate-900 max-w-2xl">
                    <?php echo esc_html($title); ?>
                </h2>
            </div>
            <div class="flex items-center gap-3">
                <button id="cs-prev"
                        class="w-14 h-14 rounded-full border border-slate-200 bg-white flex items-center justify-center hover:bg-slate-50 transition-all text-slate-400 hover:text-slate-900 group shadow-sm"
                        aria-label="<?php esc_attr_e('Poprzedni', 'meritoros'); ?>">
                    <i data-lucide="chevron-left" class="w-6 h-6 stroke-[1.5] group-hover:-translate-x-1 transition-transform"></i>
                </button>
                <button id="cs-next"
                        class="w-14 h-14 rounded-full bg-[#48c279] flex items-center justify-center hover:bg-[#3ea868] transition-all text-white shadow-lg shadow-[#48c279]/30 group"
                        aria-label="<?php esc_attr_e('Następny', 'meritoros'); ?>">
                    <i data-lucide="chevron-right" class="w-6 h-6 stroke-[2] group-hover:translate-x-1 transition-transform"></i>
                </button>
            </div>
        </div>

        <!-- Carousel Window -->
        <div class="overflow-hidden relative flex-1">
            <div id="cs-track" class="flex transition-transform duration-700 ease-in-out h-full" style="transform: translateX(0%);">

                <?php foreach ($items as $item) :
                    $client_name     = esc_html($item['client_name'] ?? '');
                    $logo_html       = wp_kses($item['client_logo_html'] ?? $client_name, [
                        'span' => ['class' => []],
                        'div'  => ['class' => []],
                        'img'  => ['src' => [], 'alt' => [], 'class' => []],
                    ]);
                    $industries_raw  = $item['industries_text'] ?? ($item['industries'] ?? []);
                    if (is_string($industries_raw) && $industries_raw !== '') {
                        $industries = array_map(fn($n) => ['name' => trim($n)], array_filter(explode(',', $industries_raw)));
                    } else {
                        $industries = is_array($industries_raw) ? $industries_raw : [];
                    }
                    $scope_title     = esc_html($item['scope_title'] ?? '');
                    $scope_desc      = esc_html($item['scope_desc'] ?? '');
                    $img_arr         = $item['image'] ?? [];
                    $img_url         = is_array($img_arr) ? esc_url($img_arr['url'] ?? '') : esc_url($img_arr);
                    $img_alt         = is_array($img_arr) ? esc_attr($img_arr['alt'] ?? $client_name) : $client_name;
                    $video_label     = esc_html($item['video_label'] ?? '');
                    $video_duration  = esc_html($item['video_duration'] ?? '');
                    $video_url       = esc_url($item['video_url'] ?? '#');
                    $cta_url         = esc_url($item['cta_url'] ?? '#');
                ?>
                    <div class="min-w-full grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 items-center h-full">

                        <!-- Content Box -->
                        <div class="bg-slate-50 border border-slate-100 rounded-[2.5rem] p-7 lg:p-10 order-2 lg:order-1 relative overflow-hidden flex flex-col h-full justify-center">
                            <div class="absolute -top-10 -right-10 w-40 h-40 bg-white blur-3xl opacity-50 rounded-full"></div>

                            <div class="flex items-center gap-2 mb-6">
                                <?php echo $logo_html; ?>
                            </div>

                            <div class="space-y-5 mb-7 relative z-10">
                                <?php if (!empty($industries)) : ?>
                                    <div>
                                        <p class="text-xs uppercase tracking-widest text-slate-400 font-bold mb-3">
                                            <?php esc_html_e('Wspierana branża', 'meritoros'); ?>
                                        </p>
                                        <div class="flex flex-wrap gap-2">
                                            <?php foreach ($industries as $ind) : ?>
                                                <span class="inline-flex items-center text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:border-slate-300 transition-colors rounded-lg px-3 py-1.5 shadow-sm">
                                                    <?php echo esc_html($ind['name'] ?? ''); ?>
                                                </span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <div class="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
                                    <p class="text-xs uppercase tracking-widest text-slate-400 font-bold mb-2">
                                        <?php esc_html_e('Zakres współpracy', 'meritoros'); ?>
                                    </p>
                                    <p class="text-base text-slate-900 font-bold mb-2 leading-snug"><?php echo $scope_title; ?></p>
                                    <p class="text-sm text-slate-600 font-light leading-relaxed"><?php echo $scope_desc; ?></p>
                                </div>
                            </div>

                            <a href="<?php echo $cta_url; ?>"
                               class="inline-flex w-fit items-center gap-2 bg-[#48c279] text-white px-6 py-3 rounded-full text-sm font-semibold hover:bg-[#3ea868] hover:shadow-lg hover:shadow-[#48c279]/30 transition-all duration-300 group/btn">
                                <?php esc_html_e('Zobacz pełne Case Study', 'meritoros'); ?>
                                <i data-lucide="arrow-right" class="w-4 h-4 group-hover/btn:translate-x-1 transition-transform"></i>
                            </a>
                        </div>

                        <!-- Image Side -->
                        <div class="relative rounded-[2.5rem] overflow-hidden group cursor-pointer aspect-[4/3] lg:aspect-auto lg:h-full min-h-[400px] shadow-sm order-1 lg:order-2">
                            <?php if ($img_url) : ?>
                                <img src="<?php echo $img_url; ?>" alt="<?php echo $img_alt; ?>"
                                     class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105">
                            <?php endif; ?>
                            <div class="absolute inset-0 bg-slate-900/20 group-hover:bg-slate-900/40 transition-colors duration-500"></div>

                            <?php if ($video_url && $video_url !== '#') : ?>
                                <a href="<?php echo $video_url; ?>" target="_blank" rel="noopener" class="absolute inset-0 flex items-center justify-center" aria-label="<?php esc_attr_e('Odtwórz wideo', 'meritoros'); ?>">
                            <?php else : ?>
                                <div class="absolute inset-0 flex items-center justify-center">
                            <?php endif; ?>
                                <div class="w-24 h-24 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-2xl transform group-hover:scale-110 transition-transform duration-500">
                                    <i data-lucide="play" class="w-10 h-10 text-[#48c279] fill-[#48c279] ml-1"></i>
                                </div>
                            <?php if ($video_url && $video_url !== '#') : ?>
                                </a>
                            <?php else : ?>
                                </div>
                            <?php endif; ?>

                            <div class="absolute bottom-6 left-6 right-6 flex items-center justify-between border-t border-white/20 pt-4">
                                <span class="text-white font-medium drop-shadow-md"><?php echo $video_label; ?></span>
                                <?php if ($video_duration) : ?>
                                    <span class="text-white/80 text-sm font-medium"><?php echo $video_duration; ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                <?php endforeach; ?>

            </div>
        </div>

        <!-- Dots -->
        <div id="cs-dots" class="flex justify-center items-center gap-3 mt-6" aria-label="<?php esc_attr_e('Nawigacja slajdów', 'meritoros'); ?>">
            <?php for ($i = 0; $i < $total; $i++) : ?>
                <button data-index="<?php echo $i; ?>"
                        class="cs-dot <?php echo $i === 0 ? 'w-10 h-2.5 bg-[#48c279]' : 'w-2.5 h-2.5 bg-slate-200 hover:bg-slate-300'; ?> rounded-full cursor-pointer transition-all duration-300"
                        aria-label="<?php printf(esc_attr__('Slajd %d', 'meritoros'), $i + 1); ?>">
                </button>
            <?php endfor; ?>
        </div>

    </div>
</section>
