<?php
$label    = mer_field('values_label', 'Nasze Wartości');
$title    = mer_field('values_title', "Dlaczego Meritoros to spokój\nw Twoim biznesie?");

// Card 1
$c1_icon  = mer_field('val_c1_icon', 'infinity');
$c1_title = mer_field('val_c1_title', "Skala i ciągłość\nobsługi");
$c1_desc  = mer_field('val_c1_desc', 'Pracujemy zespołowo i procesowo, dzięki czemu obsługa nie zależy od jednej osoby. Zapewniamy zastępowalność i ciągłość pracy – bez przestojów.');

// Card 2 — image
$img_arr  = get_field('val_img');
$img_url  = is_array($img_arr) ? esc_url($img_arr['url']) : 'https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&w=1469&q=80';
$img_alt  = is_array($img_arr) ? esc_attr($img_arr['alt']) : 'Team';
$img_hover= mer_field('val_img_hover_text', 'Współpracuj z profesjonalistami');

// Card 3
$c3_icon  = mer_field('val_c3_icon', 'shield-check');
$c3_title = mer_field('val_c3_title', "Bezpieczeństwo\ni compliance");
$c3_desc  = mer_field('val_c3_desc', 'Działamy zgodnie z obowiązującymi regulacjami i standardami bezpieczeństwa danych. Dbamy o poufność informacji oraz jasne zasady współpracy - bez "skrótów" i ryzyk.');

// Card 4
$c4_icon  = mer_field('val_c4_icon', 'bot');
$c4_title = mer_field('val_c4_title', "Technologia\ni automatyzacja");
$c4_desc  = mer_field('val_c4_desc', 'Wykorzystujemy narzędzia i automatyzację (RPA), które porządkują obieg dokumentów, ograniczają ryzyko błędów i usprawniają pracę zespołów.');

// Card 5 — awards
$c5_title  = mer_field('val_c5_title', 'Nagrody i wyróżnienia');
$c5_desc   = mer_field('val_c5_desc', 'Wyróżnienia są efektem tego, jak rozwijamy Meritoros: konsekwentnie i procesowo. Trzymamy standard, który ma działać w praktyce - codziennie.');
$awards    = mer_field('val_awards', []);
if (empty($awards)) {
    $awards = [['label' => 'GAZELE BIZNESU'], ['label' => 'Forbes']];
}

// Card 6 — quality
$c6_icon       = mer_field('val_c6_icon', 'award');
$c6_title      = mer_field('val_c6_title', 'Jakość potwierdzona standardami');
$c6_desc       = mer_field('val_c6_desc', 'Mamy wdrożone procedury kontroli jakości i weryfikacji danych. Dostarczamy spójne dane dla zarządu.');
$c6_cert_label = mer_field('val_c6_cert_label', 'Certyfikat');
$c6_cert       = mer_field('val_c6_cert', 'ISO 9001:2015');
?>

<section class="py-24 lg:py-32 px-6 lg:px-12 max-w-[1400px] mx-auto">
    <div class="text-center mb-16">
        <span class="text-[#48c279] uppercase tracking-widest text-sm font-bold mb-4 block">
            <?php echo esc_html($label); ?>
        </span>
        <h2 class="text-3xl md:text-5xl font-bold tracking-tight max-w-3xl mx-auto text-slate-900">
            <?php echo nl2br(esc_html($title)); ?>
        </h2>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">

        <!-- Card 1: White -->
        <div class="bg-white border border-slate-200 rounded-[2rem] p-8 lg:p-10 col-span-1 flex flex-col hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300 group">
            <div class="w-14 h-14 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-center mb-6 text-[#48c279] group-hover:scale-110 group-hover:bg-[#48c279] group-hover:text-white transition-all duration-300">
                <i data-lucide="<?php echo esc_attr($c1_icon); ?>" class="w-7 h-7 stroke-[1.5]"></i>
            </div>
            <h3 class="text-2xl font-bold tracking-tight mb-4 text-slate-900">
                <?php echo nl2br(esc_html($c1_title)); ?>
            </h3>
            <p class="text-lg text-slate-600 leading-relaxed font-light">
                <?php echo esc_html($c1_desc); ?>
            </p>
        </div>

        <!-- Card 2: Image -->
        <div class="col-span-1 md:col-span-2 rounded-[2rem] overflow-hidden min-h-[320px] relative group h-full cursor-pointer shadow-sm">
            <img src="<?php echo $img_url; ?>" alt="<?php echo $img_alt; ?>"
                 class="w-full h-full object-cover absolute inset-0 group-hover:scale-105 transition-transform duration-700">
            <div class="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-300"></div>
            <div class="absolute bottom-8 left-8 right-8 z-10 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                <p class="text-white font-medium text-lg flex items-center gap-2">
                    <?php echo esc_html($img_hover); ?>
                    <i data-lucide="arrow-right" class="w-5 h-5"></i>
                </p>
            </div>
        </div>

        <!-- Card 3: Dark -->
        <div class="bg-slate-900 rounded-[2rem] p-8 lg:p-10 text-white col-span-1 flex flex-col hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-900/20 transition-all duration-300 relative overflow-hidden group">
            <div class="absolute -right-10 -top-10 w-40 h-40 bg-[#48c279]/20 blur-3xl rounded-full group-hover:bg-[#48c279]/30 transition-colors"></div>
            <div class="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center mb-6 text-[#48c279] group-hover:scale-110 transition-transform duration-300">
                <i data-lucide="<?php echo esc_attr($c3_icon); ?>" class="w-7 h-7 stroke-[1.5]"></i>
            </div>
            <h3 class="text-2xl font-bold tracking-tight mb-4">
                <?php echo nl2br(esc_html($c3_title)); ?>
            </h3>
            <p class="text-lg text-slate-300 leading-relaxed font-light relative z-10">
                <?php echo esc_html($c3_desc); ?>
            </p>
        </div>

        <!-- Card 4: Green -->
        <div class="bg-[#48c279] rounded-[2rem] p-8 lg:p-10 text-white col-span-1 flex flex-col hover:-translate-y-1 hover:shadow-xl hover:shadow-[#48c279]/30 transition-all duration-300 group overflow-hidden relative">
            <div class="absolute -right-6 -bottom-6 opacity-10 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                <i data-lucide="cpu" class="w-40 h-40 stroke-[1]"></i>
            </div>
            <div class="w-fit bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-6 text-white group-hover:scale-110 transition-transform duration-300 relative z-10 p-3.5">
                <i data-lucide="<?php echo esc_attr($c4_icon); ?>" class="w-7 h-7 stroke-[1.5]"></i>
            </div>
            <h3 class="text-2xl font-bold tracking-tight mb-4 relative z-10">
                <?php echo nl2br(esc_html($c4_title)); ?>
            </h3>
            <p class="text-lg text-white/90 leading-relaxed font-light relative z-10">
                <?php echo esc_html($c4_desc); ?>
            </p>
        </div>

        <!-- Card 5: Awards -->
        <div class="bg-white border border-slate-200 rounded-[2rem] p-8 lg:p-10 col-span-1 md:col-span-2 flex flex-col justify-between hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300 group">
            <div>
                <h3 class="text-2xl font-bold tracking-tight mb-4 text-slate-900">
                    <?php echo esc_html($c5_title); ?>
                </h3>
                <p class="text-lg text-slate-600 leading-relaxed max-w-lg font-light">
                    <?php echo esc_html($c5_desc); ?>
                </p>
            </div>
            <div class="flex flex-wrap items-center gap-4 mt-8">
                <div class="flex items-center justify-center border border-slate-200 bg-slate-50 rounded-xl py-3 px-5 group-hover:border-slate-300 group-hover:bg-slate-100 transition-colors">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/images/gazele.png'); ?>" alt="Gazele Biznesu" class="h-10 w-auto object-contain">
                </div>
                <div class="flex items-center border border-slate-200 bg-slate-50 rounded-xl py-3 px-5 group-hover:border-slate-300 group-hover:bg-slate-100 transition-colors">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/images/forbes.png'); ?>" alt="Forbes" class="h-10 w-auto object-contain">
                </div>
            </div>
        </div>

        <!-- Card 6: Quality -->
        <div class="bg-slate-50 border border-slate-200 rounded-[2rem] p-8 lg:p-10 col-span-1 flex flex-col hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300 group">
            <div class="w-14 h-14 bg-white border border-slate-200 shadow-sm rounded-2xl flex items-center justify-center mb-6 text-[#48c279] group-hover:scale-110 group-hover:rotate-3 transition-transform duration-300">
                <i data-lucide="<?php echo esc_attr($c6_icon); ?>" class="w-7 h-7 stroke-[1.5]"></i>
            </div>
            <h3 class="text-2xl font-bold tracking-tight mb-4 text-slate-900">
                <?php echo esc_html($c6_title); ?>
            </h3>
            <p class="text-lg text-slate-600 leading-relaxed mb-10 font-light">
                <?php echo esc_html($c6_desc); ?>
            </p>
            <div class="mt-auto">
                <div class="w-full flex items-center justify-between border-t border-slate-200 pt-5">
                    <span class="text-xs font-bold text-slate-400 uppercase tracking-widest pl-1">
                        <?php echo esc_html($c6_cert_label); ?>
                    </span>
                    <div class="flex items-center bg-slate-900 px-3 py-2 rounded-lg shadow-sm">
                        <img src="<?php echo esc_url(get_template_directory_uri() . '/images/ISO_27001.svg'); ?>" alt="ISO 27001" class="h-8 w-auto object-contain">
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>
