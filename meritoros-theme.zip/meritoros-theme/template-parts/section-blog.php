<?php
$section_label = mer_field('blog_label', 'Wiedza i aktualności');
$section_title = mer_field('blog_title', 'Blog');
$link_text     = mer_field('blog_link_text', 'Wszystkie wpisy');
$link_url      = mer_field('blog_link_url', get_permalink(get_option('page_for_posts')) ?: '/blog');

// Query 3 latest posts
$posts = new WP_Query([
    'posts_per_page' => 3,
    'post_status'    => 'publish',
    'no_found_rows'  => true,
]);

if (!$posts->have_posts()) return;
?>

<section class="py-24 lg:py-32 px-6 lg:px-12 bg-slate-50 border-t border-slate-100">
    <div class="max-w-[1400px] mx-auto">

        <div class="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-6">
            <div>
                <span class="text-[#48c279] uppercase tracking-widest text-sm font-bold mb-4 block">
                    <?php echo esc_html($section_label); ?>
                </span>
                <h2 class="text-2xl lg:text-4xl font-bold tracking-tight text-slate-900">
                    <?php echo esc_html($section_title); ?>
                </h2>
            </div>
            <a href="<?php echo esc_url($link_url); ?>"
               class="inline-flex items-center gap-2 text-base font-semibold text-slate-500 hover:text-[#48c279] transition-colors group shrink-0">
                <?php echo esc_html($link_text); ?>
                <i data-lucide="arrow-up-right" class="w-5 h-5 stroke-[2] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"></i>
            </a>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-5 gap-6">

            <?php
            $post_index = 0;
            while ($posts->have_posts()) : $posts->the_post();
                $post_id      = get_the_ID();
                $permalink    = esc_url(get_permalink());
                $post_title   = esc_html(get_the_title());
                $excerpt      = esc_html(wp_trim_words(get_the_excerpt(), 30));
                $date         = esc_html(date_i18n('j F Y', strtotime(get_the_date('Y-m-d'))));
                $read_time    = esc_html(get_field('reading_time', $post_id) ?: '5 min czytania');
                $cat          = get_the_category($post_id);
                $cat_name     = !empty($cat) ? esc_html($cat[0]->name) : '';
                $thumb_id     = get_post_thumbnail_id($post_id);
                $thumb_url    = $thumb_id ? esc_url(wp_get_attachment_image_url($thumb_id, 'large')) : '';
                $thumb_alt    = $thumb_id ? esc_attr(get_post_meta($thumb_id, '_wp_attachment_image_alt', true)) : $post_title;
            ?>

                <?php if ($post_index === 0) : // Featured post (large) ?>
                    <article class="lg:col-span-3 group cursor-pointer flex flex-col bg-white border border-slate-200 rounded-[2.5rem] overflow-hidden hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/60 transition-all duration-300">
                        <?php if ($thumb_url) : ?>
                            <a href="<?php echo $permalink; ?>" class="relative overflow-hidden aspect-[16/9] block">
                                <img src="<?php echo $thumb_url; ?>" alt="<?php echo $thumb_alt; ?>"
                                     class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700">
                                <?php if ($cat_name) : ?>
                                    <div class="absolute top-5 left-5">
                                        <span class="inline-flex items-center gap-1.5 bg-white/90 backdrop-blur-sm text-[#48c279] text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded-full border border-[#48c279]/20">
                                            <span class="w-1.5 h-1.5 rounded-full bg-[#48c279] inline-block"></span>
                                            <?php echo $cat_name; ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </a>
                        <?php endif; ?>
                        <div class="p-8 lg:p-10 flex flex-col flex-1">
                            <div class="flex items-center gap-4 text-xs text-slate-400 font-medium mb-5">
                                <span class="flex items-center gap-1.5">
                                    <i data-lucide="calendar" class="w-3.5 h-3.5 stroke-[2]"></i>
                                    <?php echo $date; ?>
                                </span>
                                <span class="flex items-center gap-1.5">
                                    <i data-lucide="clock" class="w-3.5 h-3.5 stroke-[2]"></i>
                                    <?php echo $read_time; ?>
                                </span>
                            </div>
                            <h3 class="text-2xl lg:text-3xl font-bold tracking-tight text-slate-900 mb-4 leading-snug group-hover:text-[#48c279] transition-colors duration-300">
                                <a href="<?php echo $permalink; ?>"><?php echo $post_title; ?></a>
                            </h3>
                            <p class="text-base text-slate-600 font-light leading-relaxed mb-8 line-clamp-3">
                                <?php echo $excerpt; ?>
                            </p>
                            <div class="mt-auto">
                                <a href="<?php echo $permalink; ?>"
                                   class="inline-flex items-center gap-2 text-sm font-semibold text-slate-900 group-hover:text-[#48c279] transition-colors border-b border-slate-900 group-hover:border-[#48c279] pb-0.5">
                                    <?php esc_html_e('Przeczytaj artykuł', 'meritoros'); ?>
                                    <i data-lucide="arrow-right" class="w-4 h-4 group-hover:translate-x-1 transition-transform"></i>
                                </a>
                            </div>
                        </div>
                    </article>

                <?php else : // Small posts (right column) ?>
                    <?php if ($post_index === 1) echo '<div class="lg:col-span-2 flex flex-col gap-6">'; ?>

                    <article class="group cursor-pointer flex flex-col bg-white border border-slate-200 rounded-[2.5rem] overflow-hidden hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/60 transition-all duration-300 flex-1">
                        <?php if ($thumb_url) : ?>
                            <a href="<?php echo $permalink; ?>" class="relative overflow-hidden aspect-[16/7] block">
                                <img src="<?php echo $thumb_url; ?>" alt="<?php echo $thumb_alt; ?>"
                                     class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700">
                                <?php if ($cat_name) : ?>
                                    <div class="absolute top-4 left-4">
                                        <span class="inline-flex items-center gap-1.5 bg-white/90 backdrop-blur-sm text-slate-600 text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded-full border border-slate-200">
                                            <span class="w-1.5 h-1.5 rounded-full bg-slate-400 inline-block"></span>
                                            <?php echo $cat_name; ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </a>
                        <?php endif; ?>
                        <div class="p-6 lg:p-8 flex flex-col flex-1">
                            <div class="flex items-center gap-3 text-xs text-slate-400 font-medium mb-4">
                                <span class="flex items-center gap-1">
                                    <i data-lucide="calendar" class="w-3 h-3 stroke-[2]"></i>
                                    <?php echo $date; ?>
                                </span>
                                <span class="flex items-center gap-1">
                                    <i data-lucide="clock" class="w-3 h-3 stroke-[2]"></i>
                                    <?php echo $read_time; ?>
                                </span>
                            </div>
                            <h3 class="text-lg lg:text-xl font-bold tracking-tight text-slate-900 mb-3 leading-snug group-hover:text-[#48c279] transition-colors duration-300">
                                <a href="<?php echo $permalink; ?>"><?php echo $post_title; ?></a>
                            </h3>
                            <div class="mt-auto pt-4 border-t border-slate-100">
                                <a href="<?php echo $permalink; ?>"
                                   class="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-500 group-hover:text-[#48c279] transition-colors">
                                    <?php esc_html_e('Przeczytaj', 'meritoros'); ?>
                                    <i data-lucide="arrow-right" class="w-4 h-4 group-hover:translate-x-1 transition-transform"></i>
                                </a>
                            </div>
                        </div>
                    </article>

                    <?php if ($post_index === 2) echo '</div>'; ?>
                <?php endif; ?>

            <?php
            $post_index++;
            endwhile;
            wp_reset_postdata();
            // Close right column if only 2 posts total
            if ($post_index === 2) echo '</div>';
            ?>

        </div>
    </div>
</section>
