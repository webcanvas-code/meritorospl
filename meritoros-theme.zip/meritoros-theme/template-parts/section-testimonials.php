<?php
$label      = mer_field('testimonials_label', 'Opinie klientów');
$title      = mer_field('testimonials_title', 'Sprawdź, co mówią o nas inni');
$test_defaults = [
    1 => ['company' => 'HPC',     'logo_html' => '<span class="text-xl font-bold tracking-tight text-[#5ba3d0]">HPC</span>',         'quote' => 'Mam księgowość w bezpiecznych rękach i wiem, że nie muszę się o to już martwić.',                                                         'author' => 'Sebastian Wiśniewski', 'role' => 'HP Cepolgol S.A.',              'initials' => 'SW', 'highlighted' => false],
    2 => ['company' => 'Printbox','logo_html' => '<span class="text-lg font-bold tracking-tight text-white">Printbox</span>',        'quote' => 'Meritoros dostarczył nam stabilność i pewność, w trudnych momentach zawsze mamy właściwe odpowiedzi.',                                'author' => 'Michał Czaicki',       'role' => 'CEO & Co-Founder, Printbox', 'initials' => 'MC', 'highlighted' => true],
    3 => ['company' => 'SITECH',  'logo_html' => '<span class="text-lg font-bold tracking-tight text-slate-900">SITECH</span>',      'quote' => 'Profesjonalizm na każdym kroku. Polecamy Meritoros każdej firmie, która ceni sobie bezpieczeństwo i jakość obsługi.',                  'author' => 'Anna Kowalczyk',       'role' => 'Dyrektor Finansowy, SITECH', 'initials' => 'AK', 'highlighted' => false],
];

$items = [];
for ($i = 1; $i <= 3; $i++) {
    $def     = $test_defaults[$i];
    $items[] = [
        'company'          => mer_field("test_{$i}_company",     $def['company']),
        'company_logo_html'=> mer_field("test_{$i}_logo_html",   $def['logo_html']),
        'quote'            => mer_field("test_{$i}_quote",        $def['quote']),
        'author'           => mer_field("test_{$i}_author",       $def['author']),
        'role'             => mer_field("test_{$i}_role",         $def['role']),
        'initials'         => mer_field("test_{$i}_initials",     $def['initials']),
        'highlighted'      => (bool) mer_field("test_{$i}_highlighted", $def['highlighted']),
    ];
}

$stat_defaults = [
    1 => ['value' => '1200+', 'label' => 'Obsługiwanych klientów',  'accent' => false],
    2 => ['value' => '18+',   'label' => 'Lat na rynku',            'accent' => false],
    3 => ['value' => '98%',   'label' => 'Klientów poleca nas dalej','accent' => true],
    4 => ['value' => '35+',   'label' => 'Ekspertów w zespole',     'accent' => false],
];

$stats = [];
for ($i = 1; $i <= 4; $i++) {
    $def     = $stat_defaults[$i];
    $stats[] = [
        'value'  => mer_field("test_stat_{$i}_value",  $def['value']),
        'label'  => mer_field("test_stat_{$i}_label",  $def['label']),
        'accent' => (bool) mer_field("test_stat_{$i}_accent", $def['accent']),
    ];
}
?>

<section class="h-screen min-h-[600px] overflow-hidden px-6 lg:px-12 bg-slate-50 flex flex-col justify-center py-8 lg:py-10">
    <div class="max-w-[1400px] mx-auto w-full">

        <div class="flex flex-col md:flex-row md:items-end mb-8 gap-4">
            <div>
                <span class="text-[#48c279] uppercase tracking-widest text-sm font-bold mb-2 block">
                    <?php echo esc_html($label); ?>
                </span>
                <h2 class="text-2xl lg:text-4xl font-bold tracking-tight text-slate-900 max-w-xl">
                    <?php echo esc_html($title); ?>
                </h2>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php foreach ($items as $item) :
                $highlighted = !empty($item['highlighted']);
                $logo_html   = wp_kses($item['company_logo_html'] ?? esc_html($item['company'] ?? ''), [
                    'span' => ['class' => []],
                    'div'  => ['class' => []],
                ]);
                $quote    = esc_html($item['quote'] ?? '');
                $author   = esc_html($item['author'] ?? '');
                $role     = esc_html($item['role'] ?? '');
                $initials = esc_html($item['initials'] ?? mb_substr($item['author'] ?? 'XX', 0, 2));
            ?>
                <?php if ($highlighted) : ?>
                    <div class="bg-[#48c279] rounded-[2rem] p-5 lg:p-6 flex flex-col justify-between hover:-translate-y-1 hover:shadow-xl hover:shadow-[#48c279]/30 transition-all duration-300">
                        <div>
                            <div class="flex items-center gap-1 mb-4">
                                <?php for ($s = 0; $s < 5; $s++) : ?>
                                    <i data-lucide="star" class="w-4 h-4 fill-white text-white stroke-none"></i>
                                <?php endfor; ?>
                            </div>
                            <div class="mb-4"><?php echo $logo_html; ?></div>
                            <p class="text-sm italic font-light text-white/90 leading-relaxed mb-4">
                                &ldquo;<?php echo $quote; ?>&rdquo;
                            </p>
                        </div>
                        <div class="flex items-center gap-3 pt-4 border-t border-white/20">
                            <div class="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white font-bold text-xs shrink-0">
                                <?php echo $initials; ?>
                            </div>
                            <div>
                                <p class="text-white font-semibold text-xs"><?php echo $author; ?></p>
                                <p class="text-white/70 text-[10px]"><?php echo $role; ?></p>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <div class="bg-white border border-slate-200 rounded-[2rem] p-6 lg:p-8 flex flex-col justify-between hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300">
                        <div>
                            <div class="flex items-center gap-1 mb-6">
                                <?php for ($s = 0; $s < 5; $s++) : ?>
                                    <i data-lucide="star" class="w-5 h-5 fill-[#48c279] text-[#48c279] stroke-none"></i>
                                <?php endfor; ?>
                            </div>
                            <div class="flex items-center gap-2 mb-6"><?php echo $logo_html; ?></div>
                            <p class="text-base italic font-light text-slate-600 leading-relaxed mb-5">
                                &ldquo;<?php echo $quote; ?>&rdquo;
                            </p>
                        </div>
                        <div class="flex items-center gap-3 pt-4 border-t border-slate-100">
                            <div class="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700 font-bold text-xs shrink-0">
                                <?php echo $initials; ?>
                            </div>
                            <div>
                                <p class="text-slate-900 font-semibold text-xs"><?php echo $author; ?></p>
                                <p class="text-slate-500 text-[10px]"><?php echo $role; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>

        <!-- Stats bar -->
        <?php if (!empty($stats)) : ?>
            <div class="mt-8 pt-6 border-t border-slate-200 grid grid-cols-2 md:grid-cols-4 gap-6">
                <?php foreach ($stats as $stat) :
                    $val    = esc_html($stat['value'] ?? '');
                    $slabel = esc_html($stat['label'] ?? '');
                    $accent = !empty($stat['accent']);
                ?>
                    <div>
                        <p class="text-3xl font-bold <?php echo $accent ? 'text-[#48c279]' : 'text-slate-900'; ?> mb-1">
                            <?php echo $val; ?>
                        </p>
                        <p class="text-slate-500 text-xs font-medium"><?php echo $slabel; ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div>
</section>
