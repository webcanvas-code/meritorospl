<?php
$label     = mer_field('buyout_label', 'Dla biur rachunkowych');
$title     = mer_field('buyout_title', "Kupimy Biuro\nRachunkowe");
$desc      = mer_field('buyout_desc', 'Od lat współpracujemy z biurami rachunkowymi, które stoją przed decyzją o zmianie, sprzedaży lub dalszym rozwoju.');
$cta_text  = mer_field('buyout_cta_text', 'Wyceń wartość biura');
$cta_url   = mer_field('buyout_cta_url', '#kontakt');
$bg_arr    = get_field('buyout_bg_image');
$bg_url    = is_array($bg_arr) ? esc_url($bg_arr['url']) : 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1470&q=80';
$bg_alt    = is_array($bg_arr) ? esc_attr($bg_arr['alt']) : 'Team';
$tech_label= mer_field('tech_label', 'Obsługujemy systemy ERP i finansowe wiodących dostawców');

$stat_defaults = [
    1 => ['icon' => 'trending-up',  'value' => '100%',  'label' => 'Przejrzystych warunków', 'accent' => false],
    2 => ['icon' => 'handshake',    'value' => '20+',    'label' => 'Przejętych biur',        'accent' => false],
    3 => ['icon' => 'clock',        'value' => '14 dni', 'label' => 'Do wstępnej wyceny',     'accent' => false],
    4 => ['icon' => 'shield-check', 'value' => 'NDA',    'label' => 'Pełna poufność',         'accent' => true],
];
$stats = [];
for ($i = 1; $i <= 4; $i++) {
    $def     = $stat_defaults[$i];
    $stats[] = [
        'icon'   => mer_field("buyout_stat_{$i}_icon",   $def['icon']),
        'value'  => mer_field("buyout_stat_{$i}_value",  $def['value']),
        'label'  => mer_field("buyout_stat_{$i}_label",  $def['label']),
        'accent' => (bool) mer_field("buyout_stat_{$i}_accent", $def['accent']),
    ];
}

$tech_defaults = [
    1 => ['name' => 'COMARCH',              'subtitle' => 'ERP Optima'],
    2 => ['name' => 'enova',                'subtitle' => '365'],
    3 => ['name' => 'symfonia',             'subtitle' => ''],
    4 => ['name' => 'Microsoft Dynamics 365','subtitle' => 'Business Central'],
];
$tech_items = [];
for ($i = 1; $i <= 4; $i++) {
    $def        = $tech_defaults[$i];
    $tech_items[] = [
        'name'     => mer_field("tech_{$i}_name",     $def['name']),
        'subtitle' => mer_field("tech_{$i}_subtitle", $def['subtitle']),
        'logo_html'=> '',
    ];
}
?>

<section class="py-20 lg:py-28 px-6 lg:px-12 bg-white">
    <div class="max-w-[1400px] mx-auto">

        <!-- Buyout Banner -->
        <div class="relative rounded-[3rem] overflow-hidden">
            <div class="absolute inset-0">
                <img src="<?php echo $bg_url; ?>" alt="<?php echo $bg_alt; ?>" class="w-full h-full object-cover">
                <div class="absolute inset-0 bg-gradient-to-r from-slate-900/95 via-slate-900/80 to-slate-900/40"></div>
            </div>

            <div class="relative z-10 p-10 lg:p-16 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div class="text-white">
                    <span class="text-[#48c279] uppercase tracking-widest text-sm font-bold mb-4 block">
                        <?php echo esc_html($label); ?>
                    </span>
                    <h2 class="text-3xl md:text-5xl font-bold tracking-tight mb-6 leading-tight">
                        <?php echo nl2br(esc_html($title)); ?>
                    </h2>
                    <p class="text-lg text-white/80 mb-10 leading-relaxed max-w-lg font-light">
                        <?php echo esc_html($desc); ?>
                    </p>
                    <a href="<?php echo esc_url($cta_url); ?>"
                       class="inline-flex items-center gap-2 bg-[#48c279] text-white px-8 py-4 rounded-full text-base font-semibold hover:bg-[#3ea868] hover:shadow-lg hover:shadow-[#48c279]/30 transition-all duration-300 group">
                        <?php echo esc_html($cta_text); ?>
                        <i data-lucide="arrow-right" class="w-5 h-5 group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <?php foreach ($stats as $stat) :
                        $icon   = esc_attr($stat['icon'] ?? 'check');
                        $val    = esc_html($stat['value'] ?? '');
                        $slabel = esc_html($stat['label'] ?? '');
                        $accent = !empty($stat['accent']);
                    ?>
                        <div class="<?php echo $accent ? 'bg-[#48c279] border border-[#3ea868] hover:bg-[#3ea868]' : 'bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15'; ?> rounded-2xl p-6 transition-colors">
                            <div class="w-10 h-10 <?php echo $accent ? 'bg-white/20' : 'bg-[#48c279]/20'; ?> rounded-xl flex items-center justify-center mb-4">
                                <i data-lucide="<?php echo $icon; ?>" class="w-5 h-5 <?php echo $accent ? 'text-white' : 'text-[#48c279]'; ?> stroke-[1.5]"></i>
                            </div>
                            <p class="text-2xl font-bold text-white mb-1"><?php echo $val; ?></p>
                            <p class="text-sm <?php echo $accent ? 'text-white/80' : 'text-white/60'; ?> font-light"><?php echo $slabel; ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Tech Logos -->
        <div class="mt-16">
            <p class="text-xs uppercase tracking-widest text-slate-400 font-bold text-center mb-10">
                <?php echo esc_html($tech_label); ?>
            </p>
            <div class="flex flex-wrap justify-center lg:justify-between items-center gap-8 lg:gap-12">
                <?php foreach ($tech_items as $tech) :
                    $logo_html = !empty($tech['logo_html']) ? wp_kses($tech['logo_html'], [
                        'span' => ['class' => []],
                        'div'  => ['class' => []],
                        'img'  => ['src' => [], 'alt' => [], 'class' => []],
                    ]) : null;
                    $name    = esc_html($tech['name'] ?? '');
                    $sub     = esc_html($tech['subtitle'] ?? '');
                ?>
                    <div class="flex items-center gap-2 opacity-50 hover:opacity-100 grayscale hover:grayscale-0 transition-all duration-300 cursor-pointer group">
                        <?php if ($logo_html) : ?>
                            <?php echo $logo_html; ?>
                        <?php else : ?>
                            <span class="text-xl font-bold text-slate-700 group-hover:scale-105 transition-transform inline-block">
                                <?php echo $name; ?>
                                <?php if ($sub) : ?>
                                    <span class="block text-sm font-medium text-slate-500"><?php echo $sub; ?></span>
                                <?php endif; ?>
                            </span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</section>
