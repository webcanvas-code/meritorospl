<?php
defined('ABSPATH') || exit;

$front_page_location = [[['param' => 'page_type', 'operator' => '==', 'value' => 'front_page']]];

/* ==================================================================
   1. NAWIGACJA
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_nav',
    'title'    => '🧭 Nawigacja',
    'fields'   => [
        [
            'key'           => 'field_mer_nav_cta_text',
            'label'         => 'Tekst przycisku CTA',
            'name'          => 'nav_cta_text',
            'type'          => 'text',
            'default_value' => 'Umów rozmowę',
        ],
        [
            'key'           => 'field_mer_nav_cta_url',
            'label'         => 'Link przycisku CTA',
            'name'          => 'nav_cta_url',
            'type'          => 'text',
            'default_value' => '#kontakt',
        ],
        [
            'key'          => 'field_mer_nav_items',
            'label'        => 'Elementy menu',
            'name'         => 'nav_items',
            'type'         => 'repeater',
            'button_label' => 'Dodaj element',
            'sub_fields'   => [
                [
                    'key'   => 'field_mer_nav_item_label',
                    'label' => 'Etykieta',
                    'name'  => 'label',
                    'type'  => 'text',
                ],
                [
                    'key'   => 'field_mer_nav_item_url',
                    'label' => 'Link (opcjonalnie)',
                    'name'  => 'url',
                    'type'  => 'text',
                ],
                [
                    'key'   => 'field_mer_nav_item_has_dropdown',
                    'label' => 'Ma dropdown?',
                    'name'  => 'has_dropdown',
                    'type'  => 'true_false',
                    'ui'    => 1,
                ],
                [
                    'key'                => 'field_mer_nav_item_dropdown',
                    'label'              => 'Linki w dropdown',
                    'name'               => 'dropdown_links',
                    'type'               => 'repeater',
                    'button_label'       => 'Dodaj link',
                    'conditional_logic'  => [[['field' => 'field_mer_nav_item_has_dropdown', 'operator' => '==', 'value' => '1']]],
                    'sub_fields'         => [
                        [
                            'key'   => 'field_mer_nav_dd_label',
                            'label' => 'Etykieta',
                            'name'  => 'label',
                            'type'  => 'text',
                        ],
                        [
                            'key'   => 'field_mer_nav_dd_url',
                            'label' => 'Link',
                            'name'  => 'url',
                            'type'  => 'text',
                        ],
                    ],
                ],
            ],
        ],
    ],
    'location'   => $front_page_location,
    'menu_order' => 0,
    'position'   => 'normal',
]);

/* ==================================================================
   2. HERO
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_hero',
    'title'    => '🏠 Hero',
    'fields'   => [
        [
            'key'           => 'field_mer_hero_bg',
            'label'         => 'Zdjęcie tła',
            'name'          => 'hero_bg_image',
            'type'          => 'image',
            'return_format' => 'array',
            'preview_size'  => 'medium',
        ],
        [
            'key'           => 'field_mer_hero_headline',
            'label'         => 'Nagłówek główny',
            'name'          => 'hero_headline',
            'type'          => 'textarea',
            'rows'          => 3,
            'instructions'  => 'Każda linia tekstu będzie wyświetlona w nowej linii.',
            'default_value' => "Eksperci w księgowości.\nTechnologia i pewność\nw działaniu.",
        ],
        [
            'key'           => 'field_mer_hero_subheadline',
            'label'         => 'Podtytuł',
            'name'          => 'hero_subheadline',
            'type'          => 'textarea',
            'rows'          => 3,
            'default_value' => 'Zapewniamy księgowość kadry i outsourcing procesów w standardzie, który daje firmom spokój i bezpieczeństwo. Przejmujemy odpowiedzialność za jakość, terminowość i ciągłość obsługi.',
        ],
        [
            'key'           => 'field_mer_hero_btn1_text',
            'label'         => 'Przycisk 1 — tekst',
            'name'          => 'hero_btn1_text',
            'type'          => 'text',
            'default_value' => 'Poznaj ofertę',
        ],
        [
            'key'           => 'field_mer_hero_btn1_url',
            'label'         => 'Przycisk 1 — link',
            'name'          => 'hero_btn1_url',
            'type'          => 'text',
            'default_value' => '#uslugi',
        ],
        [
            'key'           => 'field_mer_hero_btn2_text',
            'label'         => 'Przycisk 2 — tekst',
            'name'          => 'hero_btn2_text',
            'type'          => 'text',
            'default_value' => 'Porozmawiajmy',
        ],
        [
            'key'           => 'field_mer_hero_btn2_url',
            'label'         => 'Przycisk 2 — link',
            'name'          => 'hero_btn2_url',
            'type'          => 'text',
            'default_value' => '#kontakt',
        ],
        [
            'key'           => 'field_mer_hero_trust_text',
            'label'         => 'Tekst pod paskiem klientów',
            'name'          => 'hero_trust_text',
            'type'          => 'text',
            'default_value' => 'Zaufało nam ponad <span class="text-white">1200 klientów</span>',
            'instructions'  => 'Możesz użyć HTML np. <span class="text-white">...',
        ],
        [
            'key'          => 'field_mer_hero_clients',
            'label'        => 'Logotypy klientów (pasek)',
            'name'         => 'hero_clients',
            'type'         => 'repeater',
            'button_label' => 'Dodaj klienta',
            'sub_fields'   => [
                [
                    'key'   => 'field_mer_hero_client_name',
                    'label' => 'Nazwa klienta',
                    'name'  => 'name',
                    'type'  => 'text',
                ],
            ],
        ],
    ],
    'location'   => $front_page_location,
    'menu_order' => 10,
    'position'   => 'normal',
]);

/* ==================================================================
   3. WARTOŚCI (Bento Grid)
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_values',
    'title'    => '🎯 Wartości (Bento Grid)',
    'fields'   => [
        [
            'key'           => 'field_mer_val_label',
            'label'         => 'Etykieta sekcji',
            'name'          => 'values_label',
            'type'          => 'text',
            'default_value' => 'Nasze Wartości',
        ],
        [
            'key'           => 'field_mer_val_title',
            'label'         => 'Tytuł sekcji',
            'name'          => 'values_title',
            'type'          => 'textarea',
            'rows'          => 2,
            'default_value' => "Dlaczego Meritoros to spokój\nw Twoim biznesie?",
        ],
        // Karta 1
        [
            'key'           => 'field_mer_val_c1_icon',
            'label'         => 'Karta 1 — Ikona (Lucide)',
            'name'          => 'val_c1_icon',
            'type'          => 'text',
            'default_value' => 'infinity',
        ],
        [
            'key'           => 'field_mer_val_c1_title',
            'label'         => 'Karta 1 — Tytuł',
            'name'          => 'val_c1_title',
            'type'          => 'textarea',
            'rows'          => 2,
            'default_value' => "Skala i ciągłość\nobsługi",
        ],
        [
            'key'           => 'field_mer_val_c1_desc',
            'label'         => 'Karta 1 — Opis',
            'name'          => 'val_c1_desc',
            'type'          => 'textarea',
            'default_value' => 'Pracujemy zespołowo i procesowo, dzięki czemu obsługa nie zależy od jednej osoby. Zapewniamy zastępowalność i ciągłość pracy – bez przestojów.',
        ],
        // Karta 2 — zdjęcie
        [
            'key'           => 'field_mer_val_img',
            'label'         => 'Karta 2 — Zdjęcie (środek)',
            'name'          => 'val_img',
            'type'          => 'image',
            'return_format' => 'array',
            'preview_size'  => 'medium',
        ],
        [
            'key'           => 'field_mer_val_img_hover',
            'label'         => 'Karta 2 — Tekst hover',
            'name'          => 'val_img_hover_text',
            'type'          => 'text',
            'default_value' => 'Współpracuj z profesjonalistami',
        ],
        // Karta 3 — ciemna
        [
            'key'           => 'field_mer_val_c3_icon',
            'label'         => 'Karta 3 — Ikona',
            'name'          => 'val_c3_icon',
            'type'          => 'text',
            'default_value' => 'shield-check',
        ],
        [
            'key'           => 'field_mer_val_c3_title',
            'label'         => 'Karta 3 — Tytuł',
            'name'          => 'val_c3_title',
            'type'          => 'textarea',
            'rows'          => 2,
            'default_value' => "Bezpieczeństwo\ni compliance",
        ],
        [
            'key'           => 'field_mer_val_c3_desc',
            'label'         => 'Karta 3 — Opis',
            'name'          => 'val_c3_desc',
            'type'          => 'textarea',
            'default_value' => 'Działamy zgodnie z obowiązującymi regulacjami i standardami bezpieczeństwa danych. Dbamy o poufność informacji oraz jasne zasady współpracy - bez "skrótów" i ryzyk.',
        ],
        // Karta 4 — zielona
        [
            'key'           => 'field_mer_val_c4_icon',
            'label'         => 'Karta 4 — Ikona',
            'name'          => 'val_c4_icon',
            'type'          => 'text',
            'default_value' => 'bot',
        ],
        [
            'key'           => 'field_mer_val_c4_title',
            'label'         => 'Karta 4 — Tytuł',
            'name'          => 'val_c4_title',
            'type'          => 'textarea',
            'rows'          => 2,
            'default_value' => "Technologia\ni automatyzacja",
        ],
        [
            'key'           => 'field_mer_val_c4_desc',
            'label'         => 'Karta 4 — Opis',
            'name'          => 'val_c4_desc',
            'type'          => 'textarea',
            'default_value' => 'Wykorzystujemy narzędzia i automatyzację (RPA), które porządkują obieg dokumentów, ograniczają ryzyko błędów i usprawniają pracę zespołów.',
        ],
        // Karta 5 — nagrody
        [
            'key'           => 'field_mer_val_c5_title',
            'label'         => 'Karta 5 — Tytuł',
            'name'          => 'val_c5_title',
            'type'          => 'text',
            'default_value' => 'Nagrody i wyróżnienia',
        ],
        [
            'key'           => 'field_mer_val_c5_desc',
            'label'         => 'Karta 5 — Opis',
            'name'          => 'val_c5_desc',
            'type'          => 'textarea',
            'default_value' => 'Wyróżnienia są efektem tego, jak rozwijamy Meritoros: konsekwentnie i procesowo. Trzymamy standard, który ma działać w praktyce - codziennie.',
        ],
        [
            'key'          => 'field_mer_val_awards',
            'label'        => 'Karta 5 — Nagrody',
            'name'         => 'val_awards',
            'type'         => 'repeater',
            'button_label' => 'Dodaj nagrodę',
            'sub_fields'   => [
                [
                    'key'   => 'field_mer_val_award_label',
                    'label' => 'Nazwa nagrody',
                    'name'  => 'label',
                    'type'  => 'text',
                ],
            ],
        ],
        // Karta 6 — jakość
        [
            'key'           => 'field_mer_val_c6_icon',
            'label'         => 'Karta 6 — Ikona',
            'name'          => 'val_c6_icon',
            'type'          => 'text',
            'default_value' => 'award',
        ],
        [
            'key'           => 'field_mer_val_c6_title',
            'label'         => 'Karta 6 — Tytuł',
            'name'          => 'val_c6_title',
            'type'          => 'text',
            'default_value' => 'Jakość potwierdzona standardami',
        ],
        [
            'key'           => 'field_mer_val_c6_desc',
            'label'         => 'Karta 6 — Opis',
            'name'          => 'val_c6_desc',
            'type'          => 'textarea',
            'default_value' => 'Mamy wdrożone procedury kontroli jakości i weryfikacji danych. Dostarczamy spójne dane dla zarządu.',
        ],
        [
            'key'           => 'field_mer_val_c6_cert_label',
            'label'         => 'Karta 6 — Etykieta certyfikatu',
            'name'          => 'val_c6_cert_label',
            'type'          => 'text',
            'default_value' => 'Certyfikat',
        ],
        [
            'key'           => 'field_mer_val_c6_cert',
            'label'         => 'Karta 6 — Nazwa certyfikatu',
            'name'          => 'val_c6_cert',
            'type'          => 'text',
            'default_value' => 'ISO 9001:2015',
        ],
    ],
    'location'   => $front_page_location,
    'menu_order' => 20,
    'position'   => 'normal',
]);

/* ==================================================================
   4. USŁUGI
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_services',
    'title'    => '⚙️ Usługi',
    'fields'   => [
        [
            'key'           => 'field_mer_svc_label',
            'label'         => 'Etykieta sekcji',
            'name'          => 'services_label',
            'type'          => 'text',
            'default_value' => 'Nasze Kompetencje',
        ],
        [
            'key'           => 'field_mer_svc_title',
            'label'         => 'Tytuł sekcji',
            'name'          => 'services_title',
            'type'          => 'textarea',
            'rows'          => 2,
            'default_value' => 'Obszary, w których przejmujemy odpowiedzialność',
        ],
        [
            'key'           => 'field_mer_svc_desc',
            'label'         => 'Opis sekcji',
            'name'          => 'services_desc',
            'type'          => 'textarea',
            'default_value' => 'Nasze doświadczenie obejmuje rozliczanie firm o różnorodnych profilach działalności, takich jak CIT Estoński, Fundacje Rodzinne, Spółki ASI, e-commerce, VAT OSS, Intrastat oraz rozliczenia delegacji pracowniczych.',
        ],
        ['key' => 'field_mer_svc_tab_1',   'label' => '◆ Usługa 1', 'name' => 'svc_tab_1', 'type' => 'tab'],
        ['key' => 'field_mer_svc_1_icon',  'label' => 'Ikona (Lucide)',  'name' => 'service_1_icon',  'type' => 'text',     'default_value' => 'calculator',      'instructions' => 'np. calculator, network, file-text, heart-handshake, cpu'],
        ['key' => 'field_mer_svc_1_title', 'label' => 'Tytuł',           'name' => 'service_1_title', 'type' => 'text',     'default_value' => 'Usługi Rachunkowe'],
        ['key' => 'field_mer_svc_1_desc',  'label' => 'Opis',            'name' => 'service_1_desc',  'type' => 'textarea', 'rows' => 2, 'default_value' => 'Kompleksowa obsługa księgowa firm o różnej skali działalności.'],
        ['key' => 'field_mer_svc_1_url',   'label' => 'Link',            'name' => 'service_1_url',   'type' => 'text',     'default_value' => '#'],

        ['key' => 'field_mer_svc_tab_2',   'label' => '◆ Usługa 2', 'name' => 'svc_tab_2', 'type' => 'tab'],
        ['key' => 'field_mer_svc_2_icon',  'label' => 'Ikona (Lucide)',  'name' => 'service_2_icon',  'type' => 'text',     'default_value' => 'network'],
        ['key' => 'field_mer_svc_2_title', 'label' => 'Tytuł',           'name' => 'service_2_title', 'type' => 'text',     'default_value' => 'BPO'],
        ['key' => 'field_mer_svc_2_desc',  'label' => 'Opis',            'name' => 'service_2_desc',  'type' => 'textarea', 'rows' => 2, 'default_value' => 'Outsourcing wybranych lub pełnych procesów finansowych i administracyjnych dla większych firm.'],
        ['key' => 'field_mer_svc_2_url',   'label' => 'Link',            'name' => 'service_2_url',   'type' => 'text',     'default_value' => '#'],

        ['key' => 'field_mer_svc_tab_3',   'label' => '◆ Usługa 3', 'name' => 'svc_tab_3', 'type' => 'tab'],
        ['key' => 'field_mer_svc_3_icon',  'label' => 'Ikona (Lucide)',  'name' => 'service_3_icon',  'type' => 'text',     'default_value' => 'file-text'],
        ['key' => 'field_mer_svc_3_title', 'label' => 'Tytuł',           'name' => 'service_3_title', 'type' => 'text',     'default_value' => 'Usługi Kadrowe'],
        ['key' => 'field_mer_svc_3_desc',  'label' => 'Opis',            'name' => 'service_3_desc',  'type' => 'textarea', 'rows' => 2, 'default_value' => 'Obsługa kadrowo-płacowa dopasowana do potrzeb organizacji.'],
        ['key' => 'field_mer_svc_3_url',   'label' => 'Link',            'name' => 'service_3_url',   'type' => 'text',     'default_value' => '#'],

        ['key' => 'field_mer_svc_tab_4',   'label' => '◆ Usługa 4', 'name' => 'svc_tab_4', 'type' => 'tab'],
        ['key' => 'field_mer_svc_4_icon',  'label' => 'Ikona (Lucide)',  'name' => 'service_4_icon',  'type' => 'text',     'default_value' => 'heart-handshake'],
        ['key' => 'field_mer_svc_4_title', 'label' => 'Tytuł',           'name' => 'service_4_title', 'type' => 'text',     'default_value' => 'Fundacje rodzinne'],
        ['key' => 'field_mer_svc_4_desc',  'label' => 'Opis',            'name' => 'service_4_desc',  'type' => 'textarea', 'rows' => 2, 'default_value' => 'Obsługa rachunkowa fundacji z uwzględnieniem specyfiki regulacyjnej.'],
        ['key' => 'field_mer_svc_4_url',   'label' => 'Link',            'name' => 'service_4_url',   'type' => 'text',     'default_value' => '#'],

        ['key' => 'field_mer_svc_tab_5',   'label' => '◆ Usługa 5', 'name' => 'svc_tab_5', 'type' => 'tab'],
        ['key' => 'field_mer_svc_5_icon',  'label' => 'Ikona (Lucide)',  'name' => 'service_5_icon',  'type' => 'text',     'default_value' => 'cpu'],
        ['key' => 'field_mer_svc_5_title', 'label' => 'Tytuł',           'name' => 'service_5_title', 'type' => 'text',     'default_value' => 'Transformacja Cyfrowa'],
        ['key' => 'field_mer_svc_5_desc',  'label' => 'Opis',            'name' => 'service_5_desc',  'type' => 'textarea', 'rows' => 2, 'default_value' => 'Wsparcie we wdrażaniu narzędzi, automatyzacji i usprawnianiu procesów biznesowych.'],
        ['key' => 'field_mer_svc_5_url',   'label' => 'Link',            'name' => 'service_5_url',   'type' => 'text',     'default_value' => '#'],

        ['key' => 'field_mer_svc_tab_cta', 'label' => '◆ Karta CTA', 'name' => 'svc_tab_cta', 'type' => 'tab'],
        [
            'key'           => 'field_mer_svc_cta_title',
            'label'         => 'Karta CTA — Tytuł',
            'name'          => 'services_cta_title',
            'type'          => 'text',
            'default_value' => 'Zapytaj o ofertę',
        ],
        [
            'key'           => 'field_mer_svc_cta_sub',
            'label'         => 'Karta CTA — Podtytuł',
            'name'          => 'services_cta_sub',
            'type'          => 'text',
            'default_value' => 'Skontaktuj się z nami',
        ],
        [
            'key'           => 'field_mer_svc_cta_url',
            'label'         => 'Karta CTA — Link',
            'name'          => 'services_cta_url',
            'type'          => 'text',
            'default_value' => '#kontakt',
        ],
    ],
    'location'   => $front_page_location,
    'menu_order' => 30,
    'position'   => 'normal',
]);

/* ==================================================================
   5. CASE STUDIES
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_cs',
    'title'    => '📊 Case Studies',
    'fields'   => [
        [
            'key'           => 'field_mer_cs_label',
            'label'         => 'Etykieta sekcji',
            'name'          => 'cs_label',
            'type'          => 'text',
            'default_value' => 'Case Studies',
        ],
        [
            'key'           => 'field_mer_cs_title',
            'label'         => 'Tytuł sekcji',
            'name'          => 'cs_title',
            'type'          => 'text',
            'default_value' => 'Historie naszych klientów',
        ],
        ['key' => 'field_mer_cs_tab_1', 'label' => '◆ Slajd 1', 'name' => 'cs_tab_1', 'type' => 'tab'],
        ['key' => 'field_mer_cs_1_name',     'label' => 'Nazwa klienta',       'name' => 'cs_1_client_name',  'type' => 'text',     'default_value' => 'HPC'],
        ['key' => 'field_mer_cs_1_logo',     'label' => 'Logo klienta (HTML)', 'name' => 'cs_1_logo_html',    'type' => 'textarea', 'rows' => 2, 'instructions' => 'np. <span class="text-2xl font-bold text-[#0f4c81]">HPC</span>'],
        ['key' => 'field_mer_cs_1_ind',      'label' => 'Branże',              'name' => 'cs_1_industries',   'type' => 'text',     'default_value' => 'Geologia inżynierska, Ochrona środowiska', 'instructions' => 'Oddzielone przecinkiem'],
        ['key' => 'field_mer_cs_1_stitle',   'label' => 'Zakres — Tytuł',      'name' => 'cs_1_scope_title',  'type' => 'text',     'default_value' => 'Usługi rachunkowe, obszar kadr i płac, wsparcie w audytach'],
        ['key' => 'field_mer_cs_1_sdesc',    'label' => 'Zakres — Opis',       'name' => 'cs_1_scope_desc',   'type' => 'textarea', 'rows' => 3, 'default_value' => 'Po kilku zmianach głównej księgowej spółka potrzebowała szybkiego uporządkowania księgowości i bezpiecznego zamknięcia roku obrotowego.'],
        ['key' => 'field_mer_cs_1_img',      'label' => 'Zdjęcie',             'name' => 'cs_1_image',        'type' => 'image',    'return_format' => 'array', 'preview_size' => 'medium'],
        ['key' => 'field_mer_cs_1_vlabel',   'label' => 'Opis wideo',          'name' => 'cs_1_video_label',  'type' => 'text',     'default_value' => 'Nasz wpływ na operacje HPC'],
        ['key' => 'field_mer_cs_1_vdur',     'label' => 'Czas wideo',          'name' => 'cs_1_video_dur',    'type' => 'text',     'default_value' => '03:45'],
        ['key' => 'field_mer_cs_1_vurl',     'label' => 'Link wideo',          'name' => 'cs_1_video_url',    'type' => 'text',     'default_value' => '#'],
        ['key' => 'field_mer_cs_1_cta',      'label' => 'Link "Case Study"',   'name' => 'cs_1_cta_url',      'type' => 'text',     'default_value' => '#'],

        ['key' => 'field_mer_cs_tab_2', 'label' => '◆ Slajd 2', 'name' => 'cs_tab_2', 'type' => 'tab'],
        ['key' => 'field_mer_cs_2_name',     'label' => 'Nazwa klienta',       'name' => 'cs_2_client_name',  'type' => 'text',     'default_value' => 'Printbox'],
        ['key' => 'field_mer_cs_2_logo',     'label' => 'Logo klienta (HTML)', 'name' => 'cs_2_logo_html',    'type' => 'textarea', 'rows' => 2],
        ['key' => 'field_mer_cs_2_ind',      'label' => 'Branże',              'name' => 'cs_2_industries',   'type' => 'text',     'default_value' => 'Technologia druku, E-commerce B2B', 'instructions' => 'Oddzielone przecinkiem'],
        ['key' => 'field_mer_cs_2_stitle',   'label' => 'Zakres — Tytuł',      'name' => 'cs_2_scope_title',  'type' => 'text',     'default_value' => 'Pełna obsługa BPO, rozliczenia międzynarodowe VAT OSS'],
        ['key' => 'field_mer_cs_2_sdesc',    'label' => 'Zakres — Opis',       'name' => 'cs_2_scope_desc',   'type' => 'textarea', 'rows' => 3, 'default_value' => 'Przy dynamicznym wzroście sprzedaży cross-border firma potrzebowała partnera gotowego na złożone rozliczenia VAT OSS w wielu krajach UE.'],
        ['key' => 'field_mer_cs_2_img',      'label' => 'Zdjęcie',             'name' => 'cs_2_image',        'type' => 'image',    'return_format' => 'array', 'preview_size' => 'medium'],
        ['key' => 'field_mer_cs_2_vlabel',   'label' => 'Opis wideo',          'name' => 'cs_2_video_label',  'type' => 'text',     'default_value' => 'Jak Printbox skaluje finanse globalnie'],
        ['key' => 'field_mer_cs_2_vdur',     'label' => 'Czas wideo',          'name' => 'cs_2_video_dur',    'type' => 'text',     'default_value' => '04:10'],
        ['key' => 'field_mer_cs_2_vurl',     'label' => 'Link wideo',          'name' => 'cs_2_video_url',    'type' => 'text',     'default_value' => '#'],
        ['key' => 'field_mer_cs_2_cta',      'label' => 'Link "Case Study"',   'name' => 'cs_2_cta_url',      'type' => 'text',     'default_value' => '#'],

        ['key' => 'field_mer_cs_tab_3', 'label' => '◆ Slajd 3', 'name' => 'cs_tab_3', 'type' => 'tab'],
        ['key' => 'field_mer_cs_3_name',     'label' => 'Nazwa klienta',       'name' => 'cs_3_client_name',  'type' => 'text',     'default_value' => 'SITECH'],
        ['key' => 'field_mer_cs_3_logo',     'label' => 'Logo klienta (HTML)', 'name' => 'cs_3_logo_html',    'type' => 'textarea', 'rows' => 2],
        ['key' => 'field_mer_cs_3_ind',      'label' => 'Branże',              'name' => 'cs_3_industries',   'type' => 'text',     'default_value' => 'Budownictwo, Inżynieria', 'instructions' => 'Oddzielone przecinkiem'],
        ['key' => 'field_mer_cs_3_stitle',   'label' => 'Zakres — Tytuł',      'name' => 'cs_3_scope_title',  'type' => 'text',     'default_value' => 'Kadry, płace, Intrastat, rozliczenia delegacji zagranicznych'],
        ['key' => 'field_mer_cs_3_sdesc',    'label' => 'Zakres — Opis',       'name' => 'cs_3_scope_desc',   'type' => 'textarea', 'rows' => 3, 'default_value' => 'Firma realizowała kontrakty w kilku krajach jednocześnie. Meritoros przejął obsługę kadrową i rozliczenia Intrastat.'],
        ['key' => 'field_mer_cs_3_img',      'label' => 'Zdjęcie',             'name' => 'cs_3_image',        'type' => 'image',    'return_format' => 'array', 'preview_size' => 'medium'],
        ['key' => 'field_mer_cs_3_vlabel',   'label' => 'Opis wideo',          'name' => 'cs_3_video_label',  'type' => 'text',     'default_value' => 'Obsługa kadrowa na skalę międzynarodową'],
        ['key' => 'field_mer_cs_3_vdur',     'label' => 'Czas wideo',          'name' => 'cs_3_video_dur',    'type' => 'text',     'default_value' => '05:22'],
        ['key' => 'field_mer_cs_3_vurl',     'label' => 'Link wideo',          'name' => 'cs_3_video_url',    'type' => 'text',     'default_value' => '#'],
        ['key' => 'field_mer_cs_3_cta',      'label' => 'Link "Case Study"',   'name' => 'cs_3_cta_url',      'type' => 'text',     'default_value' => '#'],

        ['key' => 'field_mer_cs_tab_4', 'label' => '◆ Slajd 4', 'name' => 'cs_tab_4', 'type' => 'tab'],
        ['key' => 'field_mer_cs_4_name',     'label' => 'Nazwa klienta',       'name' => 'cs_4_client_name',  'type' => 'text'],
        ['key' => 'field_mer_cs_4_logo',     'label' => 'Logo klienta (HTML)', 'name' => 'cs_4_logo_html',    'type' => 'textarea', 'rows' => 2, 'instructions' => 'Zostaw puste, aby ukryć slajd 4'],
        ['key' => 'field_mer_cs_4_ind',      'label' => 'Branże',              'name' => 'cs_4_industries',   'type' => 'text',     'instructions' => 'Oddzielone przecinkiem'],
        ['key' => 'field_mer_cs_4_stitle',   'label' => 'Zakres — Tytuł',      'name' => 'cs_4_scope_title',  'type' => 'text'],
        ['key' => 'field_mer_cs_4_sdesc',    'label' => 'Zakres — Opis',       'name' => 'cs_4_scope_desc',   'type' => 'textarea', 'rows' => 3],
        ['key' => 'field_mer_cs_4_img',      'label' => 'Zdjęcie',             'name' => 'cs_4_image',        'type' => 'image',    'return_format' => 'array', 'preview_size' => 'medium'],
        ['key' => 'field_mer_cs_4_vlabel',   'label' => 'Opis wideo',          'name' => 'cs_4_video_label',  'type' => 'text'],
        ['key' => 'field_mer_cs_4_vdur',     'label' => 'Czas wideo',          'name' => 'cs_4_video_dur',    'type' => 'text'],
        ['key' => 'field_mer_cs_4_vurl',     'label' => 'Link wideo',          'name' => 'cs_4_video_url',    'type' => 'text',     'default_value' => '#'],
        ['key' => 'field_mer_cs_4_cta',      'label' => 'Link "Case Study"',   'name' => 'cs_4_cta_url',      'type' => 'text',     'default_value' => '#'],
    ],
    'location'   => $front_page_location,
    'menu_order' => 40,
    'position'   => 'normal',
]);

/* ==================================================================
   6. OPINIE
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_testimonials',
    'title'    => '⭐ Opinie klientów',
    'fields'   => [
        [
            'key'           => 'field_mer_test_label',
            'label'         => 'Etykieta sekcji',
            'name'          => 'testimonials_label',
            'type'          => 'text',
            'default_value' => 'Opinie klientów',
        ],
        [
            'key'           => 'field_mer_test_title',
            'label'         => 'Tytuł sekcji',
            'name'          => 'testimonials_title',
            'type'          => 'text',
            'default_value' => 'Sprawdź, co mówią o nas inni',
        ],
        ['key' => 'field_mer_test_tab_1', 'label' => '◆ Opinia 1', 'name' => 'test_tab_1', 'type' => 'tab'],
        ['key' => 'field_mer_t1_company', 'label' => 'Firma',                    'name' => 'test_1_company',     'type' => 'text',      'default_value' => 'HPC'],
        ['key' => 'field_mer_t1_logo',    'label' => 'Logo firmy (HTML)',         'name' => 'test_1_logo_html',   'type' => 'textarea',  'rows' => 2, 'instructions' => 'Opcjonalnie. Jeśli puste — wyświetlana jest nazwa firmy.'],
        ['key' => 'field_mer_t1_quote',   'label' => 'Treść opinii',             'name' => 'test_1_quote',       'type' => 'textarea',  'rows' => 3, 'default_value' => 'Mam księgowość w bezpiecznych rękach i wiem, że nie muszę się o to już martwić.'],
        ['key' => 'field_mer_t1_author',  'label' => 'Imię i nazwisko',          'name' => 'test_1_author',      'type' => 'text',      'default_value' => 'Sebastian Wiśniewski'],
        ['key' => 'field_mer_t1_role',    'label' => 'Stanowisko / firma',       'name' => 'test_1_role',        'type' => 'text',      'default_value' => 'HP Cepolgol S.A.'],
        ['key' => 'field_mer_t1_init',    'label' => 'Inicjały (awatar, 2 znaki)','name' => 'test_1_initials',   'type' => 'text',      'default_value' => 'SW'],
        ['key' => 'field_mer_t1_hl',      'label' => 'Wyróżniona karta (zielona)','name' => 'test_1_highlighted','type' => 'true_false','ui' => 1, 'default_value' => 0],

        ['key' => 'field_mer_test_tab_2', 'label' => '◆ Opinia 2', 'name' => 'test_tab_2', 'type' => 'tab'],
        ['key' => 'field_mer_t2_company', 'label' => 'Firma',                    'name' => 'test_2_company',     'type' => 'text',      'default_value' => 'Printbox'],
        ['key' => 'field_mer_t2_logo',    'label' => 'Logo firmy (HTML)',         'name' => 'test_2_logo_html',   'type' => 'textarea',  'rows' => 2],
        ['key' => 'field_mer_t2_quote',   'label' => 'Treść opinii',             'name' => 'test_2_quote',       'type' => 'textarea',  'rows' => 3, 'default_value' => 'Meritoros dostarczył nam stabilność i pewność, w trudnych momentach zawsze mamy właściwe odpowiedzi.'],
        ['key' => 'field_mer_t2_author',  'label' => 'Imię i nazwisko',          'name' => 'test_2_author',      'type' => 'text',      'default_value' => 'Michał Czaicki'],
        ['key' => 'field_mer_t2_role',    'label' => 'Stanowisko / firma',       'name' => 'test_2_role',        'type' => 'text',      'default_value' => 'CEO & Co-Founder, Printbox'],
        ['key' => 'field_mer_t2_init',    'label' => 'Inicjały (awatar, 2 znaki)','name' => 'test_2_initials',   'type' => 'text',      'default_value' => 'MC'],
        ['key' => 'field_mer_t2_hl',      'label' => 'Wyróżniona karta (zielona)','name' => 'test_2_highlighted','type' => 'true_false','ui' => 1, 'default_value' => 1],

        ['key' => 'field_mer_test_tab_3', 'label' => '◆ Opinia 3', 'name' => 'test_tab_3', 'type' => 'tab'],
        ['key' => 'field_mer_t3_company', 'label' => 'Firma',                    'name' => 'test_3_company',     'type' => 'text',      'default_value' => 'SITECH'],
        ['key' => 'field_mer_t3_logo',    'label' => 'Logo firmy (HTML)',         'name' => 'test_3_logo_html',   'type' => 'textarea',  'rows' => 2],
        ['key' => 'field_mer_t3_quote',   'label' => 'Treść opinii',             'name' => 'test_3_quote',       'type' => 'textarea',  'rows' => 3, 'default_value' => 'Profesjonalizm na każdym kroku. Polecamy Meritoros każdej firmie, która ceni sobie bezpieczeństwo i jakość obsługi.'],
        ['key' => 'field_mer_t3_author',  'label' => 'Imię i nazwisko',          'name' => 'test_3_author',      'type' => 'text',      'default_value' => 'Anna Kowalczyk'],
        ['key' => 'field_mer_t3_role',    'label' => 'Stanowisko / firma',       'name' => 'test_3_role',        'type' => 'text',      'default_value' => 'Dyrektor Finansowy, SITECH'],
        ['key' => 'field_mer_t3_init',    'label' => 'Inicjały (awatar, 2 znaki)','name' => 'test_3_initials',   'type' => 'text',      'default_value' => 'AK'],
        ['key' => 'field_mer_t3_hl',      'label' => 'Wyróżniona karta (zielona)','name' => 'test_3_highlighted','type' => 'true_false','ui' => 1, 'default_value' => 0],

        ['key' => 'field_mer_test_tab_stats', 'label' => '◆ Statystyki', 'name' => 'test_tab_stats', 'type' => 'tab'],
        ['key' => 'field_mer_ts1_val',  'label' => 'Statystyka 1 — Wartość',  'name' => 'test_stat_1_value', 'type' => 'text',      'default_value' => '1200+'],
        ['key' => 'field_mer_ts1_lbl',  'label' => 'Statystyka 1 — Etykieta', 'name' => 'test_stat_1_label', 'type' => 'text',      'default_value' => 'Obsługiwanych klientów'],
        ['key' => 'field_mer_ts1_acc',  'label' => 'Statystyka 1 — Zielony',  'name' => 'test_stat_1_accent','type' => 'true_false','ui' => 1, 'default_value' => 0],
        ['key' => 'field_mer_ts2_val',  'label' => 'Statystyka 2 — Wartość',  'name' => 'test_stat_2_value', 'type' => 'text',      'default_value' => '18+'],
        ['key' => 'field_mer_ts2_lbl',  'label' => 'Statystyka 2 — Etykieta', 'name' => 'test_stat_2_label', 'type' => 'text',      'default_value' => 'Lat na rynku'],
        ['key' => 'field_mer_ts2_acc',  'label' => 'Statystyka 2 — Zielony',  'name' => 'test_stat_2_accent','type' => 'true_false','ui' => 1, 'default_value' => 0],
        ['key' => 'field_mer_ts3_val',  'label' => 'Statystyka 3 — Wartość',  'name' => 'test_stat_3_value', 'type' => 'text',      'default_value' => '98%'],
        ['key' => 'field_mer_ts3_lbl',  'label' => 'Statystyka 3 — Etykieta', 'name' => 'test_stat_3_label', 'type' => 'text',      'default_value' => 'Klientów poleca nas dalej'],
        ['key' => 'field_mer_ts3_acc',  'label' => 'Statystyka 3 — Zielony',  'name' => 'test_stat_3_accent','type' => 'true_false','ui' => 1, 'default_value' => 1],
        ['key' => 'field_mer_ts4_val',  'label' => 'Statystyka 4 — Wartość',  'name' => 'test_stat_4_value', 'type' => 'text',      'default_value' => '35+'],
        ['key' => 'field_mer_ts4_lbl',  'label' => 'Statystyka 4 — Etykieta', 'name' => 'test_stat_4_label', 'type' => 'text',      'default_value' => 'Ekspertów w zespole'],
        ['key' => 'field_mer_ts4_acc',  'label' => 'Statystyka 4 — Zielony',  'name' => 'test_stat_4_accent','type' => 'true_false','ui' => 1, 'default_value' => 0],
    ],
    'location'   => $front_page_location,
    'menu_order' => 50,
    'position'   => 'normal',
]);

/* ==================================================================
   7. SKUP BIUR / BANER
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_buyout',
    'title'    => '🏢 Skup biur rachunkowych',
    'fields'   => [
        [
            'key'           => 'field_mer_buy_label',
            'label'         => 'Etykieta sekcji',
            'name'          => 'buyout_label',
            'type'          => 'text',
            'default_value' => 'Dla biur rachunkowych',
        ],
        [
            'key'           => 'field_mer_buy_title',
            'label'         => 'Tytuł',
            'name'          => 'buyout_title',
            'type'          => 'textarea',
            'rows'          => 2,
            'default_value' => "Kupimy Biuro\nRachunkowe",
        ],
        [
            'key'           => 'field_mer_buy_desc',
            'label'         => 'Opis',
            'name'          => 'buyout_desc',
            'type'          => 'textarea',
            'default_value' => 'Od lat współpracujemy z biurami rachunkowymi, które stoją przed decyzją o zmianie, sprzedaży lub dalszym rozwoju. Oferujemy wsparcie na każdym etapie — od wyceny po finalne ustalenia.',
        ],
        [
            'key'           => 'field_mer_buy_cta_text',
            'label'         => 'Przycisk — tekst',
            'name'          => 'buyout_cta_text',
            'type'          => 'text',
            'default_value' => 'Wyceń wartość biura',
        ],
        [
            'key'           => 'field_mer_buy_cta_url',
            'label'         => 'Przycisk — link',
            'name'          => 'buyout_cta_url',
            'type'          => 'text',
            'default_value' => '#kontakt',
        ],
        [
            'key'           => 'field_mer_buy_bg',
            'label'         => 'Zdjęcie tła banera',
            'name'          => 'buyout_bg_image',
            'type'          => 'image',
            'return_format' => 'array',
            'preview_size'  => 'medium',
        ],
        ['key' => 'field_mer_buy_tab_stats', 'label' => '◆ Statystyki', 'name' => 'buy_tab_stats', 'type' => 'tab'],
        ['key' => 'field_mer_bs1_icon',  'label' => 'Karta 1 — Ikona (Lucide)',    'name' => 'buyout_stat_1_icon',  'type' => 'text',      'default_value' => 'trending-up'],
        ['key' => 'field_mer_bs1_val',   'label' => 'Karta 1 — Wartość',           'name' => 'buyout_stat_1_value', 'type' => 'text',      'default_value' => '100%'],
        ['key' => 'field_mer_bs1_lbl',   'label' => 'Karta 1 — Etykieta',          'name' => 'buyout_stat_1_label', 'type' => 'text',      'default_value' => 'Przejrzystych warunków'],
        ['key' => 'field_mer_bs1_acc',   'label' => 'Karta 1 — Zielone tło',       'name' => 'buyout_stat_1_accent','type' => 'true_false','ui' => 1, 'default_value' => 0],
        ['key' => 'field_mer_bs2_icon',  'label' => 'Karta 2 — Ikona (Lucide)',    'name' => 'buyout_stat_2_icon',  'type' => 'text',      'default_value' => 'handshake'],
        ['key' => 'field_mer_bs2_val',   'label' => 'Karta 2 — Wartość',           'name' => 'buyout_stat_2_value', 'type' => 'text',      'default_value' => '20+'],
        ['key' => 'field_mer_bs2_lbl',   'label' => 'Karta 2 — Etykieta',          'name' => 'buyout_stat_2_label', 'type' => 'text',      'default_value' => 'Przejętych biur'],
        ['key' => 'field_mer_bs2_acc',   'label' => 'Karta 2 — Zielone tło',       'name' => 'buyout_stat_2_accent','type' => 'true_false','ui' => 1, 'default_value' => 0],
        ['key' => 'field_mer_bs3_icon',  'label' => 'Karta 3 — Ikona (Lucide)',    'name' => 'buyout_stat_3_icon',  'type' => 'text',      'default_value' => 'clock'],
        ['key' => 'field_mer_bs3_val',   'label' => 'Karta 3 — Wartość',           'name' => 'buyout_stat_3_value', 'type' => 'text',      'default_value' => '14 dni'],
        ['key' => 'field_mer_bs3_lbl',   'label' => 'Karta 3 — Etykieta',          'name' => 'buyout_stat_3_label', 'type' => 'text',      'default_value' => 'Do wstępnej wyceny'],
        ['key' => 'field_mer_bs3_acc',   'label' => 'Karta 3 — Zielone tło',       'name' => 'buyout_stat_3_accent','type' => 'true_false','ui' => 1, 'default_value' => 0],
        ['key' => 'field_mer_bs4_icon',  'label' => 'Karta 4 — Ikona (Lucide)',    'name' => 'buyout_stat_4_icon',  'type' => 'text',      'default_value' => 'shield-check'],
        ['key' => 'field_mer_bs4_val',   'label' => 'Karta 4 — Wartość',           'name' => 'buyout_stat_4_value', 'type' => 'text',      'default_value' => 'NDA'],
        ['key' => 'field_mer_bs4_lbl',   'label' => 'Karta 4 — Etykieta',          'name' => 'buyout_stat_4_label', 'type' => 'text',      'default_value' => 'Pełna poufność'],
        ['key' => 'field_mer_bs4_acc',   'label' => 'Karta 4 — Zielone tło',       'name' => 'buyout_stat_4_accent','type' => 'true_false','ui' => 1, 'default_value' => 1],

        // Tech logos
        ['key' => 'field_mer_buy_tab_tech', 'label' => '◆ Logotypy ERP', 'name' => 'buy_tab_tech', 'type' => 'tab'],
        [
            'key'           => 'field_mer_tech_label',
            'label'         => 'Etykieta sekcji logotypów ERP',
            'name'          => 'tech_label',
            'type'          => 'text',
            'default_value' => 'Obsługujemy systemy ERP i finansowe wiodących dostawców',
        ],
        ['key' => 'field_mer_tech_1_name', 'label' => 'System 1 — Nazwa',    'name' => 'tech_1_name',     'type' => 'text',     'default_value' => 'COMARCH'],
        ['key' => 'field_mer_tech_1_sub',  'label' => 'System 1 — Podtytuł', 'name' => 'tech_1_subtitle', 'type' => 'text',     'default_value' => 'ERP Optima'],
        ['key' => 'field_mer_tech_2_name', 'label' => 'System 2 — Nazwa',    'name' => 'tech_2_name',     'type' => 'text',     'default_value' => 'enova'],
        ['key' => 'field_mer_tech_2_sub',  'label' => 'System 2 — Podtytuł', 'name' => 'tech_2_subtitle', 'type' => 'text',     'default_value' => '365'],
        ['key' => 'field_mer_tech_3_name', 'label' => 'System 3 — Nazwa',    'name' => 'tech_3_name',     'type' => 'text',     'default_value' => 'symfonia'],
        ['key' => 'field_mer_tech_3_sub',  'label' => 'System 3 — Podtytuł', 'name' => 'tech_3_subtitle', 'type' => 'text'],
        ['key' => 'field_mer_tech_4_name', 'label' => 'System 4 — Nazwa',    'name' => 'tech_4_name',     'type' => 'text',     'default_value' => 'Microsoft Dynamics 365'],
        ['key' => 'field_mer_tech_4_sub',  'label' => 'System 4 — Podtytuł', 'name' => 'tech_4_subtitle', 'type' => 'text',     'default_value' => 'Business Central'],
    ],
    'location'   => $front_page_location,
    'menu_order' => 60,
    'position'   => 'normal',
]);

/* ==================================================================
   8. BLOG (sekcja na stronie głównej)
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_blog',
    'title'    => '📝 Blog (sekcja główna)',
    'fields'   => [
        [
            'key'           => 'field_mer_blog_label',
            'label'         => 'Etykieta sekcji',
            'name'          => 'blog_label',
            'type'          => 'text',
            'default_value' => 'Wiedza i aktualności',
        ],
        [
            'key'           => 'field_mer_blog_title',
            'label'         => 'Tytuł sekcji',
            'name'          => 'blog_title',
            'type'          => 'text',
            'default_value' => 'Blog',
        ],
        [
            'key'           => 'field_mer_blog_link_text',
            'label'         => 'Link — tekst',
            'name'          => 'blog_link_text',
            'type'          => 'text',
            'default_value' => 'Wszystkie wpisy',
        ],
        [
            'key'           => 'field_mer_blog_link_url',
            'label'         => 'Link — adres',
            'name'          => 'blog_link_url',
            'type'          => 'text',
            'default_value' => '/blog',
        ],
    ],
    'location'   => $front_page_location,
    'menu_order' => 70,
    'position'   => 'normal',
]);

// Custom field for reading time on posts
acf_add_local_field_group([
    'key'      => 'group_mer_post_meta',
    'title'    => 'Metadane artykułu',
    'fields'   => [
        [
            'key'           => 'field_mer_reading_time',
            'label'         => 'Czas czytania (np. "5 min")',
            'name'          => 'reading_time',
            'type'          => 'text',
            'default_value' => '5 min czytania',
        ],
    ],
    'location'   => [[['param' => 'post_type', 'operator' => '==', 'value' => 'post']]],
    'menu_order' => 0,
    'position'   => 'side',
]);

/* ==================================================================
   9. NEWSLETTER
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_newsletter',
    'title'    => '📧 Newsletter',
    'fields'   => [
        [
            'key'           => 'field_mer_nl_label',
            'label'         => 'Etykieta sekcji',
            'name'          => 'nl_label',
            'type'          => 'text',
            'default_value' => 'Newsletter',
        ],
        [
            'key'           => 'field_mer_nl_title',
            'label'         => 'Tytuł (lewa strona)',
            'name'          => 'nl_title',
            'type'          => 'text',
            'default_value' => 'Bądź na bieżąco ze zmianami podatkowymi',
        ],
        [
            'key'           => 'field_mer_nl_desc',
            'label'         => 'Opis (lewa strona)',
            'name'          => 'nl_desc',
            'type'          => 'textarea',
            'default_value' => 'Interesują Cię zmiany podatkowe? Szukasz pracy w obszarze księgowości lub kadr? Zapisz się i otrzymuj to, co ważne.',
        ],
        ['key' => 'field_mer_nl_benefit_1', 'label' => 'Korzyść 1', 'name' => 'nl_benefit_1', 'type' => 'text', 'default_value' => 'Miesięczne podsumowania zmian podatkowych'],
        ['key' => 'field_mer_nl_benefit_2', 'label' => 'Korzyść 2', 'name' => 'nl_benefit_2', 'type' => 'text', 'default_value' => 'Aktualne oferty pracy z obszaru finansów i kadr'],
        ['key' => 'field_mer_nl_benefit_3', 'label' => 'Korzyść 3', 'name' => 'nl_benefit_3', 'type' => 'text', 'default_value' => 'Praktyczne wskazówki i komentarze ekspertów'],
        ['key' => 'field_mer_nl_benefit_4', 'label' => 'Korzyść 4', 'name' => 'nl_benefit_4', 'type' => 'text', 'default_value' => 'Możliwość wypisania się w dowolnym momencie'],
        [
            'key'           => 'field_mer_nl_sub_count',
            'label'         => 'Liczba subskrybentów',
            'name'          => 'nl_subscriber_count',
            'type'          => 'text',
            'default_value' => '2 400+ czytelników',
        ],
        [
            'key'           => 'field_mer_nl_sub_label',
            'label'         => 'Etykieta subskrybentów',
            'name'          => 'nl_subscriber_label',
            'type'          => 'text',
            'default_value' => 'dołączyło do naszego newslettera',
        ],
        [
            'key'           => 'field_mer_nl_form_title',
            'label'         => 'Tytuł formularza',
            'name'          => 'nl_form_title',
            'type'          => 'text',
            'default_value' => 'Zapisz się bezpłatnie',
        ],
        [
            'key'           => 'field_mer_nl_form_sub',
            'label'         => 'Podtytuł formularza',
            'name'          => 'nl_form_sub',
            'type'          => 'text',
            'default_value' => 'Dołącz do ponad 2 400 specjalistów finansowych.',
        ],
        ['key' => 'field_mer_nl_topic_1', 'label' => 'Checkbox 1', 'name' => 'nl_topic_1', 'type' => 'text', 'default_value' => 'Zmiany podatkowe i księgowe'],
        ['key' => 'field_mer_nl_topic_2', 'label' => 'Checkbox 2', 'name' => 'nl_topic_2', 'type' => 'text', 'default_value' => 'Oferty pracy (kadry, płace, finanse)'],
        [
            'key'           => 'field_mer_nl_rodo',
            'label'         => 'Tekst RODO',
            'name'          => 'nl_rodo',
            'type'          => 'textarea',
            'default_value' => 'Administratorem danych jest Meritoros SA, Aleja Pokoju 62/8, Kraków. Dane przetwarzane są wyłącznie w celu wysyłki newslettera. Możesz wypisać się w każdej chwili.',
        ],
        [
            'key'           => 'field_mer_nl_privacy_url',
            'label'         => 'Link Polityki Prywatności',
            'name'          => 'nl_privacy_url',
            'type'          => 'text',
            'default_value' => '/polityka-prywatnosci',
        ],
        [
            'key'           => 'field_mer_nl_terms_url',
            'label'         => 'Link Regulaminu',
            'name'          => 'nl_terms_url',
            'type'          => 'text',
            'default_value' => '/regulamin-newslettera',
        ],
        [
            'key'           => 'field_mer_nl_form_action',
            'label'         => 'Akcja formularza (URL)',
            'name'          => 'nl_form_action',
            'type'          => 'text',
            'instructions'  => 'URL do wysyłki formularza, np. MailerLite, Mailchimp embed URL.',
            'default_value' => '#',
        ],
    ],
    'location'   => $front_page_location,
    'menu_order' => 80,
    'position'   => 'normal',
]);

/* ==================================================================
   10. STOPKA
================================================================== */
acf_add_local_field_group([
    'key'      => 'group_mer_footer',
    'title'    => '🔚 Stopka',
    'fields'   => [
        [
            'key'           => 'field_mer_footer_cta_label',
            'label'         => 'CTA — Etykieta',
            'name'          => 'footer_cta_label',
            'type'          => 'text',
            'default_value' => 'Zacznij teraz',
        ],
        [
            'key'           => 'field_mer_footer_cta_title',
            'label'         => 'CTA — Tytuł',
            'name'          => 'footer_cta_title',
            'type'          => 'textarea',
            'rows'          => 2,
            'default_value' => "Dołącz do grona naszych\nklientów i rozwijaj biznes",
        ],
        [
            'key'           => 'field_mer_footer_cta_accent',
            'label'         => 'CTA — Akcentowany fragment (zielony)',
            'name'          => 'footer_cta_accent',
            'type'          => 'text',
            'default_value' => 'bez stresu',
        ],
        [
            'key'           => 'field_mer_footer_btn1_text',
            'label'         => 'Przycisk 1 — tekst',
            'name'          => 'footer_btn1_text',
            'type'          => 'text',
            'default_value' => 'Umów rozmowę',
        ],
        [
            'key'           => 'field_mer_footer_btn1_url',
            'label'         => 'Przycisk 1 — link',
            'name'          => 'footer_btn1_url',
            'type'          => 'text',
            'default_value' => '#kontakt',
        ],
        [
            'key'           => 'field_mer_footer_btn2_text',
            'label'         => 'Przycisk 2 — tekst',
            'name'          => 'footer_btn2_text',
            'type'          => 'text',
            'default_value' => 'Poznaj ofertę',
        ],
        [
            'key'           => 'field_mer_footer_btn2_url',
            'label'         => 'Przycisk 2 — link',
            'name'          => 'footer_btn2_url',
            'type'          => 'text',
            'default_value' => '#uslugi',
        ],
        [
            'key'           => 'field_mer_footer_tagline',
            'label'         => 'Tagline (pod logo)',
            'name'          => 'footer_tagline',
            'type'          => 'textarea',
            'rows'          => 2,
            'default_value' => 'Profesjonalne biuro rachunkowe i BPO dla firm z ambicjami.',
        ],
        ['key' => 'field_mer_footer_tab_social', 'label' => '◆ Social media', 'name' => 'footer_tab_social', 'type' => 'tab'],
        ['key' => 'field_mer_social_1_icon', 'label' => 'Social 1 — Ikona (Lucide)', 'name' => 'footer_social_1_icon', 'type' => 'text', 'default_value' => 'facebook',  'instructions' => 'np. facebook, instagram, linkedin, youtube, twitter'],
        ['key' => 'field_mer_social_1_url',  'label' => 'Social 1 — Link',           'name' => 'footer_social_1_url',  'type' => 'text', 'default_value' => '#'],
        ['key' => 'field_mer_social_2_icon', 'label' => 'Social 2 — Ikona (Lucide)', 'name' => 'footer_social_2_icon', 'type' => 'text', 'default_value' => 'instagram'],
        ['key' => 'field_mer_social_2_url',  'label' => 'Social 2 — Link',           'name' => 'footer_social_2_url',  'type' => 'text', 'default_value' => '#'],
        ['key' => 'field_mer_social_3_icon', 'label' => 'Social 3 — Ikona (Lucide)', 'name' => 'footer_social_3_icon', 'type' => 'text', 'default_value' => 'linkedin'],
        ['key' => 'field_mer_social_3_url',  'label' => 'Social 3 — Link',           'name' => 'footer_social_3_url',  'type' => 'text', 'default_value' => '#'],
        ['key' => 'field_mer_social_4_icon', 'label' => 'Social 4 — Ikona (Lucide)', 'name' => 'footer_social_4_icon', 'type' => 'text', 'default_value' => 'youtube'],
        ['key' => 'field_mer_social_4_url',  'label' => 'Social 4 — Link',           'name' => 'footer_social_4_url',  'type' => 'text', 'default_value' => '#'],
        ['key' => 'field_mer_footer_tab_contact', 'label' => '◆ Kontakt', 'name' => 'footer_tab_contact', 'type' => 'tab'],
        [
            'key'           => 'field_mer_footer_address',
            'label'         => 'Adres',
            'name'          => 'footer_address',
            'type'          => 'text',
            'default_value' => 'Aleja Pokoju 62/8, Kraków',
        ],
        [
            'key'           => 'field_mer_footer_phone',
            'label'         => 'Telefon',
            'name'          => 'footer_phone',
            'type'          => 'text',
            'default_value' => '+48 000 000 000',
        ],
        [
            'key'           => 'field_mer_footer_email',
            'label'         => 'E-mail',
            'name'          => 'footer_email',
            'type'          => 'email',
            'default_value' => 'biuro@meritoros.pl',
        ],
        [
            'key'           => 'field_mer_footer_copyright',
            'label'         => 'Copyright',
            'name'          => 'footer_copyright',
            'type'          => 'text',
            'default_value' => '© 2026 Meritoros SA. Wszelkie prawa zastrzeżone.',
        ],
        [
            'key'           => 'field_mer_footer_credit_text',
            'label'         => 'Projekt i realizacja — tekst',
            'name'          => 'footer_credit_text',
            'type'          => 'text',
            'default_value' => 'Web-Canvas',
        ],
        [
            'key'           => 'field_mer_footer_credit_url',
            'label'         => 'Projekt i realizacja — link',
            'name'          => 'footer_credit_url',
            'type'          => 'text',
            'default_value' => 'https://web-canvas.pl',
        ],
    ],
    'location'   => $front_page_location,
    'menu_order' => 90,
    'position'   => 'normal',
]);
