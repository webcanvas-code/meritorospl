<?php
$cta_label   = mer_field('footer_cta_label', 'Zacznij teraz');
$cta_title   = mer_field('footer_cta_title', "Dołącz do grona naszych\nklientów i rozwijaj biznes");
$cta_accent  = mer_field('footer_cta_accent', 'bez stresu');
$btn1_text   = mer_field('footer_btn1_text', 'Umów rozmowę');
$btn1_url    = mer_field('footer_btn1_url', '#kontakt');
$btn2_text   = mer_field('footer_btn2_text', 'Poznaj ofertę');
$btn2_url    = mer_field('footer_btn2_url', '#uslugi');
$tagline     = mer_field('footer_tagline', 'Profesjonalne biuro rachunkowe i BPO dla firm z ambicjami.');
$address     = mer_field('footer_address', 'Aleja Pokoju 62/8, Kraków');
$phone       = mer_field('footer_phone', '+48 000 000 000');
$email       = mer_field('footer_email', 'biuro@meritoros.pl');
$copyright   = mer_field('footer_copyright', '© ' . date('Y') . ' Meritoros SA. Wszelkie prawa zastrzeżone.');
$credit_text = mer_field('footer_credit_text', 'Web-Canvas');
$credit_url  = mer_field('footer_credit_url', '#');

$social_defaults = [
    1 => ['icon' => 'facebook',  'url' => '#'],
    2 => ['icon' => 'instagram', 'url' => '#'],
    3 => ['icon' => 'linkedin',  'url' => '#'],
    4 => ['icon' => 'youtube',   'url' => '#'],
];
$socials = [];
for ($i = 1; $i <= 4; $i++) {
    $def  = $social_defaults[$i];
    $icon = mer_field("footer_social_{$i}_icon", $def['icon']);
    $url  = mer_field("footer_social_{$i}_url",  $def['url']);
    if (!empty($icon)) {
        $socials[] = ['icon' => $icon, 'url' => $url];
    }
}
?>

<footer class="bg-slate-900 text-white px-6 lg:px-12 pt-0 pb-0">
    <div class="max-w-[1400px] mx-auto">

        <!-- Footer CTA Banner -->
        <div class="border-b border-white/10 py-12 sm:py-16 lg:py-20 flex flex-col lg:flex-row lg:items-center justify-between gap-8 sm:gap-10">
            <div class="max-w-2xl">
                <span class="text-[#48c279] uppercase tracking-widest text-sm font-bold mb-4 block">
                    <?php echo esc_html($cta_label); ?>
                </span>
                <h2 class="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight leading-tight">
                    <?php echo nl2br(esc_html($cta_title)); ?><br>
                    <span class="text-[#48c279]"><?php echo esc_html($cta_accent); ?></span>
                </h2>
            </div>
            <div class="flex flex-col sm:flex-row gap-4 shrink-0">
                <a href="<?php echo esc_url($btn1_url); ?>"
                   class="inline-flex items-center gap-2 bg-[#48c279] text-white px-8 py-4 rounded-full text-base font-bold hover:bg-[#3ea868] hover:shadow-lg hover:shadow-[#48c279]/30 transition-all duration-300 group">
                    <?php echo esc_html($btn1_text); ?>
                    <i data-lucide="arrow-right" class="w-5 h-5 group-hover:translate-x-1 transition-transform"></i>
                </a>
                <a href="<?php echo esc_url($btn2_url); ?>"
                   class="inline-flex items-center gap-2 border border-white/20 text-white px-8 py-4 rounded-full text-base font-semibold hover:bg-white/10 transition-all duration-300">
                    <?php echo esc_html($btn2_text); ?>
                </a>
            </div>
        </div>

        <!-- Footer Links Grid -->
        <div class="py-10 sm:py-12 lg:py-14 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 sm:gap-8 lg:gap-10">

            <!-- Brand column -->
            <div class="col-span-2 md:col-span-4 lg:col-span-1 flex flex-col gap-6">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/logo.svg'); ?>" alt="<?php bloginfo('name'); ?>" class="h-8 w-auto brightness-0 invert">
                </a>
                <p class="text-slate-400 text-sm font-light leading-relaxed max-w-[200px]">
                    <?php echo esc_html($tagline); ?>
                </p>
                <!-- Social icons -->
                <div class="flex items-center gap-2">
                    <?php foreach ($socials as $social) :
                        $icon = esc_attr($social['icon'] ?? 'link');
                        $url  = esc_url($social['url'] ?? '#');
                    ?>
                        <a href="<?php echo $url; ?>" rel="noopener noreferrer" target="_blank"
                           class="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#48c279] transition-colors duration-300"
                           aria-label="<?php echo $icon; ?>">
                            <i data-lucide="<?php echo $icon; ?>" class="w-4 h-4 stroke-[1.5]"></i>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Site map -->
            <div>
                <h4 class="text-xs uppercase tracking-widest font-bold text-slate-400 mb-5">
                    <?php esc_html_e('Mapa strony', 'meritoros'); ?>
                </h4>
                <?php
                wp_nav_menu([
                    'theme_location' => 'footer',
                    'menu_class'     => 'space-y-3 text-sm text-slate-300',
                    'container'      => false,
                    'fallback_cb'    => function () {
                        echo '<ul class="space-y-3 text-sm text-slate-300">';
                        $items = ['Biuro rachunkowe', 'BPO', 'O nas', 'Odkryj', 'Kariera', 'Kontakt'];
                        foreach ($items as $item) {
                            echo '<li><a href="#" class="hover:text-white hover:translate-x-0.5 transition-all inline-block">' . esc_html($item) . '</a></li>';
                        }
                        echo '</ul>';
                    },
                ]);
                ?>
            </div>

            <!-- Services column -->
            <div>
                <h4 class="text-xs uppercase tracking-widest font-bold text-slate-400 mb-5">
                    <?php esc_html_e('Usługi', 'meritoros'); ?>
                </h4>
                <ul class="space-y-3 text-sm text-slate-300">
                    <li><a href="#" class="hover:text-white hover:translate-x-0.5 transition-all inline-block"><?php esc_html_e('Usługi księgowe', 'meritoros'); ?></a></li>
                    <li><a href="#" class="hover:text-white hover:translate-x-0.5 transition-all inline-block"><?php esc_html_e('Kadry i płace', 'meritoros'); ?></a></li>
                    <li><a href="#" class="hover:text-white hover:translate-x-0.5 transition-all inline-block"><?php esc_html_e('Fundacje rodzinne', 'meritoros'); ?></a></li>
                    <li><a href="#" class="hover:text-white hover:translate-x-0.5 transition-all inline-block"><?php esc_html_e('Skup biur rachunkowych', 'meritoros'); ?></a></li>
                </ul>
            </div>

            <!-- Info column -->
            <div>
                <h4 class="text-xs uppercase tracking-widest font-bold text-slate-400 mb-5">
                    <?php esc_html_e('Informacje', 'meritoros'); ?>
                </h4>
                <ul class="space-y-3 text-sm text-slate-300">
                    <li><a href="<?php echo esc_url(mer_field('nl_privacy_url', '#')); ?>" class="hover:text-white hover:translate-x-0.5 transition-all inline-block"><?php esc_html_e('Polityka prywatności', 'meritoros'); ?></a></li>
                    <li><a href="<?php echo esc_url(mer_field('nl_terms_url', '#')); ?>" class="hover:text-white hover:translate-x-0.5 transition-all inline-block"><?php esc_html_e('Regulamin newslettera', 'meritoros'); ?></a></li>
                    <li><a href="/blog" class="hover:text-white hover:translate-x-0.5 transition-all inline-block"><?php esc_html_e('Blog', 'meritoros'); ?></a></li>
                </ul>
            </div>

            <!-- Contact column -->
            <div>
                <h4 class="text-xs uppercase tracking-widest font-bold text-slate-400 mb-5">
                    <?php esc_html_e('Kontakt', 'meritoros'); ?>
                </h4>
                <ul class="space-y-3 text-sm text-slate-300">
                    <?php if ($address) : ?>
                        <li class="flex items-start gap-2">
                            <i data-lucide="map-pin" class="w-4 h-4 text-[#48c279] mt-0.5 shrink-0 stroke-[1.5]"></i>
                            <span><?php echo nl2br(esc_html($address)); ?></span>
                        </li>
                    <?php endif; ?>
                    <?php if ($phone) : ?>
                        <li class="flex items-center gap-2">
                            <i data-lucide="phone" class="w-4 h-4 text-[#48c279] shrink-0 stroke-[1.5]"></i>
                            <a href="tel:<?php echo esc_attr(preg_replace('/\s+/', '', $phone)); ?>" class="hover:text-white transition-colors">
                                <?php echo esc_html($phone); ?>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if ($email) : ?>
                        <li class="flex items-center gap-2">
                            <i data-lucide="mail" class="w-4 h-4 text-[#48c279] shrink-0 stroke-[1.5]"></i>
                            <a href="mailto:<?php echo esc_attr($email); ?>" class="hover:text-white transition-colors">
                                <?php echo esc_html($email); ?>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <!-- Bottom bar -->
        <div class="flex flex-col md:flex-row items-center justify-between text-xs text-slate-500 py-6 border-t border-white/10 gap-4">
            <p><?php echo esc_html($copyright); ?></p>
            <p><?php esc_html_e('Projekt i realizacja:', 'meritoros'); ?>
                <a href="<?php echo esc_url($credit_url); ?>" class="text-slate-400 hover:text-white transition-colors ml-1">
                    <?php echo esc_html($credit_text); ?>
                </a>
            </p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
