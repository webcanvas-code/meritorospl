/**
 * Meritoros Theme — Main JS
 * Initializes Lucide icons, mobile menu, and case studies carousel.
 */

document.addEventListener('DOMContentLoaded', () => {

    // ----------------------------------------------------------------
    // Lucide icons
    // ----------------------------------------------------------------
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // ----------------------------------------------------------------
    // Mobile menu toggle
    // ----------------------------------------------------------------
    const mobileBtn  = document.getElementById('mobile-menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    if (mobileBtn && mobileMenu) {
        mobileBtn.addEventListener('click', () => {
            const isHidden = mobileMenu.classList.contains('hidden');
            mobileMenu.classList.toggle('hidden', !isHidden);
            mobileBtn.setAttribute('aria-expanded', String(isHidden));
        });
    }

    // ----------------------------------------------------------------
    // Case Studies Carousel
    // ----------------------------------------------------------------
    const track   = document.getElementById('cs-track');
    const dotsWrap= document.getElementById('cs-dots');
    const prevBtn = document.getElementById('cs-prev');
    const nextBtn = document.getElementById('cs-next');

    if (!track || !dotsWrap) return;

    const slides = track.querySelectorAll('.min-w-full');
    const dots   = dotsWrap.querySelectorAll('.cs-dot');
    const total  = slides.length;
    let current  = 0;
    let timer    = null;

    const goTo = (index) => {
        current = ((index % total) + total) % total;
        track.style.transform = `translateX(-${current * 100}%)`;

        dots.forEach((dot, i) => {
            const isActive = i === current;
            dot.classList.toggle('bg-[#48c279]', isActive);
            dot.classList.toggle('w-10', isActive);
            dot.classList.toggle('bg-slate-200', !isActive);
            dot.classList.toggle('w-2.5', !isActive);
        });
    };

    const resetTimer = () => {
        clearInterval(timer);
        timer = setInterval(() => goTo(current + 1), 6000);
    };

    if (prevBtn) prevBtn.addEventListener('click', () => { goTo(current - 1); resetTimer(); });
    if (nextBtn) nextBtn.addEventListener('click', () => { goTo(current + 1); resetTimer(); });

    dots.forEach(dot => {
        dot.addEventListener('click', () => {
            goTo(parseInt(dot.dataset.index, 10));
            resetTimer();
        });
    });

    // Swipe support (touch)
    let touchStartX = 0;
    track.addEventListener('touchstart', (e) => { touchStartX = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', (e) => {
        const diff = touchStartX - e.changedTouches[0].clientX;
        if (Math.abs(diff) > 50) {
            goTo(diff > 0 ? current + 1 : current - 1);
            resetTimer();
        }
    }, { passive: true });

    // Auto-play
    resetTimer();

});
