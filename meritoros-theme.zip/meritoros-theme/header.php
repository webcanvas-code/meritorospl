<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>

<body <?php body_class('bg-slate-50 text-slate-900 antialiased'); ?>>
<?php wp_body_open(); ?>

<?php
$nav_cta_text = mer_field('nav_cta_text', 'Umów rozmowę');
$nav_cta_url  = mer_field('nav_cta_url', '#kontakt');
$nav_items    = mer_field('nav_items', []);

// Defaults when no ACF data
if (empty($nav_items)) {
    $nav_items = [
        ['label' => 'Biuro rachunkowe', 'url' => '#', 'has_dropdown' => true,  'dropdown_links' => [
            ['label' => 'Usługi księgowe', 'url' => '#'],
            ['label' => 'Kadry i płace',   'url' => '#'],
            ['label' => 'Fundacje rodzinne','url' => '#'],
        ]],
        ['label' => 'BPO',     'url' => '#', 'has_dropdown' => false, 'dropdown_links' => []],
        ['label' => 'O nas',   'url' => '#', 'has_dropdown' => false, 'dropdown_links' => []],
        ['label' => 'Odkryj',  'url' => '#', 'has_dropdown' => false, 'dropdown_links' => []],
        ['label' => 'Kariera', 'url' => '#', 'has_dropdown' => false, 'dropdown_links' => []],
        ['label' => 'Kontakt', 'url' => '#', 'has_dropdown' => false, 'dropdown_links' => []],
    ];
}
?>

<header class="absolute top-6 left-0 right-0 z-50 px-6 lg:px-12 w-full max-w-[1400px] mx-auto">
    <div class="bg-[#f2f4f6]/70 backdrop-blur-md rounded-full px-4 py-3 flex justify-between items-center shadow-lg shadow-black/5">

        <!-- Logo -->
        <a href="<?php echo esc_url(home_url('/')); ?>" class="flex items-center pl-4">
            <img src="<?php echo esc_url(get_template_directory_uri() . '/logo.svg'); ?>" alt="<?php bloginfo('name'); ?>" class="h-8 w-auto">
        </a>

        <!-- Desktop Nav -->
        <nav class="hidden lg:flex items-center gap-8 text-slate-900 text-[15px] font-medium" aria-label="<?php esc_attr_e('Menu główne', 'meritoros'); ?>">
            <?php foreach ($nav_items as $item) :
                $label       = esc_html($item['label'] ?? '');
                $url         = esc_url($item['url'] ?? '#');
                $has_dropdown = !empty($item['has_dropdown']);
                $dropdown    = $item['dropdown_links'] ?? [];
            ?>
                <?php if ($has_dropdown && !empty($dropdown)) : ?>
                    <div class="relative group">
                        <a href="<?php echo $url; ?>"
                           class="flex items-center gap-1.5 hover:text-slate-600 transition-colors py-4 -my-4 cursor-pointer">
                            <?php echo $label; ?>
                            <i data-lucide="chevron-down" class="w-4 h-4 text-[#48c279] stroke-[1.5]"></i>
                        </a>
                        <div class="absolute top-full left-1/2 -translate-x-1/2 pt-6 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50 w-[260px]">
                            <div class="bg-[#f2f4f6] rounded-[2rem] p-7 flex flex-col gap-5 shadow-xl shadow-black/5 border border-white/60">
                                <?php foreach ($dropdown as $dd) : ?>
                                    <a href="<?php echo esc_url($dd['url'] ?? '#'); ?>"
                                       class="flex items-center justify-between text-slate-900 hover:text-slate-600 group/item transition-colors">
                                        <span class="text-[15px]"><?php echo esc_html($dd['label'] ?? ''); ?></span>
                                        <i data-lucide="arrow-up-right" class="w-5 h-5 text-[#48c279] stroke-[1.5] group-hover/item:translate-x-0.5 group-hover/item:-translate-y-0.5 transition-transform"></i>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php else : ?>
                    <a href="<?php echo $url; ?>" class="hover:text-slate-600 transition-colors"><?php echo $label; ?></a>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>

        <!-- CTA -->
        <div class="hidden lg:block pr-2">
            <a href="<?php echo esc_url($nav_cta_url); ?>"
               class="bg-[#48c279] text-white px-7 py-3 rounded-full text-[15px] font-medium hover:bg-[#3ea868] transition-colors">
                <?php echo esc_html($nav_cta_text); ?>
            </a>
        </div>

        <!-- Mobile menu button -->
        <button id="mobile-menu-btn" class="lg:hidden text-slate-900 pr-4" aria-expanded="false" aria-label="<?php esc_attr_e('Otwórz menu', 'meritoros'); ?>">
            <i data-lucide="menu" class="w-7 h-7 stroke-[1.5]"></i>
        </button>
    </div>

    <!-- Mobile menu -->
    <div id="mobile-menu" class="hidden lg:hidden mt-3 bg-[#f2f4f6]/95 backdrop-blur-md rounded-3xl px-6 py-6 shadow-xl">
        <nav class="flex flex-col gap-4 text-slate-900 text-base font-medium">
            <?php foreach ($nav_items as $item) : ?>
                <a href="<?php echo esc_url($item['url'] ?? '#'); ?>"
                   class="hover:text-slate-600 transition-colors py-1">
                    <?php echo esc_html($item['label'] ?? ''); ?>
                </a>
            <?php endforeach; ?>
            <a href="<?php echo esc_url($nav_cta_url); ?>"
               class="mt-2 bg-[#48c279] text-white px-6 py-3 rounded-full text-center font-medium hover:bg-[#3ea868] transition-colors">
                <?php echo esc_html($nav_cta_text); ?>
            </a>
        </nav>
    </div>
</header>
