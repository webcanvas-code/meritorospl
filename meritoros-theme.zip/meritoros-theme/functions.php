<?php
defined('ABSPATH') || exit;

/* ------------------------------------------------------------------
   Theme Setup
------------------------------------------------------------------ */
function meritoros_setup(): void {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'gallery', 'caption', 'script', 'style']);
    add_theme_support('custom-logo');

    load_theme_textdomain('meritoros', get_template_directory() . '/languages');

    register_nav_menus([
        'primary' => __('Menu główne', 'meritoros'),
        'footer'  => __('Menu stopki', 'meritoros'),
    ]);
}
add_action('after_setup_theme', 'meritoros_setup');

/* ------------------------------------------------------------------
   Enqueue Scripts & Styles
------------------------------------------------------------------ */
function meritoros_scripts(): void {
    wp_enqueue_style(
        'google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
        [],
        null
    );

    wp_enqueue_style('meritoros-style', get_stylesheet_uri(), [], '1.0.0');

    // Tailwind CDN (production: replace with compiled build)
    wp_enqueue_script('tailwind-cdn', 'https://cdn.tailwindcss.com', [], null, false);

    // Lucide icons
    wp_enqueue_script('lucide', 'https://unpkg.com/lucide@latest', [], null, true);

    // Main theme script
    wp_enqueue_script(
        'meritoros-main',
        get_template_directory_uri() . '/assets/js/main.js',
        ['lucide'],
        '1.0.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'meritoros_scripts');

/* ------------------------------------------------------------------
   ACF Field Groups
------------------------------------------------------------------ */
add_action('acf/init', function () {
    require get_template_directory() . '/inc/acf-fields.php';
});


/* ------------------------------------------------------------------
   Helpers
------------------------------------------------------------------ */

/**
 * Get ACF field with optional fallback.
 */
function mer_field(string $name, $fallback = ''): mixed {
    $value = get_field($name);
    return ($value !== null && $value !== false && $value !== '') ? $value : $fallback;
}

/**
 * Get ACF sub-field with optional fallback.
 */
function mer_sub(string $name, $fallback = ''): mixed {
    $value = get_sub_field($name);
    return ($value !== null && $value !== false && $value !== '') ? $value : $fallback;
}

/**
 * Output escaped text or nl2br textarea.
 */
function mer_text(string $name, string $fallback = '', bool $nl2br = false): void {
    $val = mer_field($name, $fallback);
    $val = esc_html($val);
    echo $nl2br ? nl2br($val) : $val;
}

/**
 * Output ACF image as <img> tag.
 *
 * @param string $name     Field name
 * @param string $class    CSS classes
 * @param string $alt      Fallback alt text
 */
function mer_img(string $name, string $class = '', string $alt = ''): void {
    $img = get_field($name);
    if (is_array($img)) {
        $src  = esc_url($img['url']);
        $alt  = esc_attr($img['alt'] ?: $alt);
        $w    = intval($img['width']);
        $h    = intval($img['height']);
        echo "<img src=\"{$src}\" alt=\"{$alt}\" class=\"{$class}\" width=\"{$w}\" height=\"{$h}\">";
    } elseif ($alt) {
        echo '<img src="" alt="' . esc_attr($alt) . '" class="' . esc_attr($class) . '">';
    }
}

/**
 * Output ACF image URL only.
 */
function mer_img_url(string $name, string $fallback = ''): string {
    $img = get_field($name);
    if (is_array($img)) {
        return esc_url($img['url']);
    }
    return esc_url($fallback);
}

/**
 * Return lucide <i> icon markup.
 */
function mer_icon(string $name_field, string $fallback_icon, string $class = ''): string {
    $icon = esc_attr(mer_field($name_field, $fallback_icon));
    return "<i data-lucide=\"{$icon}\" class=\"{$class}\"></i>";
}
